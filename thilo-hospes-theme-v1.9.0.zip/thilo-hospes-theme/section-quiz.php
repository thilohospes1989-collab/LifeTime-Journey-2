<?php
/**
 * Orientierungs-Quiz — LifeTime Journey
 *
 * EINBINDUNG in front-page.php, direkt vor <div id="leitpfade":
 *   <?php get_template_part('section-quiz'); ?>
 *
 * VOLLAUTOMATISCH — nichts einpflegen, nichts konfigurieren.
 * Artikel in WordPress veröffentlichen → erscheint sofort im Quiz.
 * Titel in WordPress müssen exakt mit den Titeln hier übereinstimmen.
 */

// ── TITEL-MAPPING ─────────────────────────────────────────────────────────────
// Schlüssel = Quiz-ID  |  Wert = exakter Titel in WordPress
$ltj_titles = [
  // PFAD A — AKUT
  'a1-a' => 'Der Moment, in dem alles anders wird',
  'a2-a' => 'Funktionieren müssen, während man innerlich zerbricht',
  'a3-a' => 'Was ein Zusammenbruch wirklich bedeutet',
  // PFAD A — PHASE 1
  'p1-a-koerper'       => 'Was mit meinem Körper passiert',
  'p1-a-schweigen'     => 'Warum ich nicht rede',
  'p1-a-widerspruch'   => 'Warum fühle ich mich so widersprüchlich?',
  'p1-a-funktionieren' => 'Ich funktioniere — aber das bin nicht ich',
  // PFAD A — PHASE 2
  'p2-a-dosierung'    => 'Wie viel Trauer kann ich mir pro Tag zumuten?',
  'p2-a-alltag'       => 'Warum ist alles so schwer, obwohl ich nur meinen Alltag lebe?',
  'p2-a-normalitaet'  => 'Ich will manchmal einfach normal sein',
  'p2-a-vergleiche'   => 'Warum Vergleiche verletzen',
  'p2-a-schwanger'    => 'Ich gönne es ihr — und kann es trotzdem kaum aushalten',
  'p2-a-therapie'     => 'Wann ist Therapie sinnvoll?',
  'p2-a-selbsthilfe'  => 'Was bringen Selbsthilfegruppen?',
  // PFAD A — PHASE 3
  'p3-a-sprache'      => 'Sätze, die wehtun — und warum',
  'p3-a-partner'      => 'Warum mein Partner mich nicht versteht — und ich ihn nicht',
  'p3-a-freundschaft' => 'Warum manche Menschen verschwinden — und was das macht',
  'p3-a-beruf'        => 'Zurückkommen — alle tun als wäre nichts',
  'p3-a-zeitdruck'    => 'Gesellschaftlicher Druck und mein eigenes Tempo',
  'p3-a-grenzen'      => 'Ich brauche Nähe — und kann sie kaum aushalten',
  // PFAD A — PHASE 4
  'p4-a-erinnerung'   => 'Mein Kind ist nicht weg — es hat nur eine andere Form',
  'p4-a-jahrestage'   => 'Warum mein Körper Daten kennt',
  'p4-a-humor'        => 'Darf ich lachen, wenn ich trauere?',
  // PFAD B — AKUT
  'a1-b' => 'Danebenstehen, wenn Worte nicht möglich sind',
  'a2-b' => 'Wo ist die Grenze beim Organisieren?',
  'a3-b' => 'Was tun, wenn jemand wirklich zusammenbricht?',
  // PFAD B — PHASE 1
  'p1-b-signale'       => 'Warum sendet der andere so verschiedene Signale?',
  'p1-b-schweigen'     => 'Schweigen aushalten ohne es zu füllen',
  'p1-b-koerper'       => 'Körperliche Zeichen lesen, ohne zu interpretieren',
  'p1-b-funktionieren' => 'Funktionieren ist keine Stabilität',
  // PFAD B — PHASE 2
  'p2-b-dosierung'     => 'Wie begleite ich jemanden ohne zu drängen oder zu bremsen?',
  'p2-b-hilflosigkeit' => 'Nicht-helfen-Können aushalten — und trotzdem bleiben',
  'p2-b-alltag'        => 'Neben jemandem leben, der im Alltag kämpft',
  'p2-b-normalitaet'   => 'Wann ist Normalität Hilfe, wann Flucht?',
  'p2-b-schwanger'     => 'Soll ich es erwähnen? Soll ich schweigen?',
  'p2-b-therapie'      => 'Wie spreche ich Therapie an, ohne zu drängen?',
  'p2-b-selbsthilfe'   => 'Wie unterstütze ich jemanden beim ersten Schritt?',
  // PFAD B — PHASE 3
  'p3-b-sprache'       => 'Was sagen, was nicht sagen, wie schweigen',
  'p3-b-partner'       => 'Wie begleite ich jemanden, mit dem ich selbst trauere?',
  'p3-b-freundschaft'  => 'Ich weiß nicht mehr, wie ich da sein soll',
  'p3-b-beruf'         => 'Als Kollege oder Führungskraft — was ist angemessen?',
  'p3-b-zeitdruck'     => 'Darf ich nach Jahren noch fragen?',
  'p3-b-grenzen'       => 'Verfügbar bleiben, ohne aufzudrängen',
  // PFAD B — PHASE 4
  'p4-b-erinnerung'    => 'Raum halten für jemanden, den ich nie kannte',
  'p4-b-jahrestage'    => 'Ansprechen oder übergehen?',
  'p4-b-humor'         => 'Wann ist Leichtigkeit erlaubt?',
];

$ltj_tags = [
  'a1-a'=>'Pfad A · Akut','a2-a'=>'Pfad A · Akut','a3-a'=>'Pfad A · Akut',
  'p1-a-koerper'=>'Pfad A · Phase 1','p1-a-schweigen'=>'Pfad A · Phase 1',
  'p1-a-widerspruch'=>'Pfad A · Phase 1','p1-a-funktionieren'=>'Pfad A · Phase 1',
  'p2-a-dosierung'=>'Pfad A · Phase 2','p2-a-alltag'=>'Pfad A · Phase 2',
  'p2-a-normalitaet'=>'Pfad A · Phase 2','p2-a-vergleiche'=>'Pfad A · Phase 2',
  'p2-a-schwanger'=>'Pfad A · Phase 2','p2-a-therapie'=>'Pfad A · Phase 2',
  'p2-a-selbsthilfe'=>'Pfad A · Phase 2',
  'p3-a-sprache'=>'Pfad A · Phase 3','p3-a-partner'=>'Pfad A · Phase 3',
  'p3-a-freundschaft'=>'Pfad A · Phase 3','p3-a-beruf'=>'Pfad A · Phase 3',
  'p3-a-zeitdruck'=>'Pfad A · Phase 3','p3-a-grenzen'=>'Pfad A · Phase 3',
  'p4-a-erinnerung'=>'Pfad A · Phase 4','p4-a-jahrestage'=>'Pfad A · Phase 4','p4-a-humor'=>'Pfad A · Phase 4',
  'a1-b'=>'Pfad B · Akut','a2-b'=>'Pfad B · Akut','a3-b'=>'Pfad B · Akut',
  'p1-b-signale'=>'Pfad B · Phase 1','p1-b-schweigen'=>'Pfad B · Phase 1',
  'p1-b-koerper'=>'Pfad B · Phase 1','p1-b-funktionieren'=>'Pfad B · Phase 1',
  'p2-b-dosierung'=>'Pfad B · Phase 2','p2-b-hilflosigkeit'=>'Pfad B · Phase 2',
  'p2-b-alltag'=>'Pfad B · Phase 2','p2-b-normalitaet'=>'Pfad B · Phase 2',
  'p2-b-schwanger'=>'Pfad B · Phase 2','p2-b-therapie'=>'Pfad B · Phase 2',
  'p2-b-selbsthilfe'=>'Pfad B · Phase 2',
  'p3-b-sprache'=>'Pfad B · Phase 3','p3-b-partner'=>'Pfad B · Phase 3',
  'p3-b-freundschaft'=>'Pfad B · Phase 3','p3-b-beruf'=>'Pfad B · Phase 3',
  'p3-b-zeitdruck'=>'Pfad B · Phase 3','p3-b-grenzen'=>'Pfad B · Phase 3',
  'p4-b-erinnerung'=>'Pfad B · Phase 4','p4-b-jahrestage'=>'Pfad B · Phase 4','p4-b-humor'=>'Pfad B · Phase 4',
];

$ltj_fallback_desc = [
  'a1-a'=>'Was im Krankenhaus passiert — und warum du nicht weißt, wie du reagieren sollst.',
  'a2-a'=>'Wie du durch die Beerdigung kommst, wenn du eigentlich nicht kannst.',
  'a3-a'=>'Warum Zusammenbrüche keine Schwäche sind — und was in dir passiert.',
  'p1-a-koerper'=>'Rückzug, Leere, Enge, Erstarren — dein Körper reagiert auf Trauer.',
  'p1-a-schweigen'=>'Frühe Trauer ist oft sprachlos. Hier erfährst du, warum — und was das bedeutet.',
  'p1-a-widerspruch'=>'Gleichzeitig weinen und lachen wollen — das ist keine Störung, das ist Trauer.',
  'p1-a-funktionieren'=>'Wenn du nach außen stabil wirkst, aber innen nicht weißt, wer du bist.',
  'p2-a-dosierung'=>'Trauer braucht Dosierung, kein Tempo. Dein Toleranzfenster kennen.',
  'p2-a-alltag'=>'Der Alltag nach dem Verlust — und warum er sich so fremd anfühlt.',
  'p2-a-normalitaet'=>'Normalität nach dem Verlust — Flucht oder echtes Atemholen?',
  'p2-a-vergleiche'=>'„Das war doch kein richtiger Verlust..." — was solche Sätze machen.',
  'p2-a-schwanger'=>'Wenn andere schwanger sind, während du trauerst.',
  'p2-a-therapie'=>'Wann Therapie sinnvoll ist — und wie du das für dich erkennen kannst.',
  'p2-a-selbsthilfe'=>'Wann sie helfen, wann nicht — und wie du den ersten Schritt machst.',
  'p3-a-sprache'=>'Was andere sagen und warum es so trifft. Und was du damit machen kannst.',
  'p3-a-partner'=>'Zwei Menschen, eine Trauer, zwei völlig verschiedene Wege.',
  'p3-a-freundschaft'=>'Wenn Freundschaften nach dem Verlust zerbrechen — und was das macht.',
  'p3-a-beruf'=>'Der Wiedereinstieg ins Arbeitsleben und wie du damit umgehst.',
  'p3-a-zeitdruck'=>'„Wann bist du endlich wieder normal?" — was du diesem Druck entgegnen kannst.',
  'p3-a-grenzen'=>'Wenn du Kontakt willst, aber gleichzeitig abschalten möchtest.',
  'p4-a-erinnerung'=>'Erinnerung und Bindung als Teil des Trauerprozesses — was bleibt.',
  'p4-a-jahrestage'=>'Jahrestage und Triggerpunkte — wenn der Körper erinnert, bevor der Kopf es tut.',
  'p4-a-humor'=>'Warum Lachen und Trauern kein Widerspruch ist — und was das über dich sagt.',
  'a1-b'=>'Was du im Krankenhaus tun kannst — auch wenn du nichts tun kannst.',
  'a2-b'=>'Wie du bei der Beerdigung hilfst, ohne die Kontrolle zu übernehmen.',
  'a3-b'=>'Wenn derjenige, dem du beistehst, zusammenbricht — was jetzt hilft.',
  'p1-b-signale'=>'Widersprüchliche Reaktionen in der Trauer — und was dahintersteckt.',
  'p1-b-schweigen'=>'Was es wirklich bedeutet, einfach dabei zu sein.',
  'p1-b-koerper'=>'Wie du körperliche Trauersignale erkennst und richtig einordnest.',
  'p1-b-funktionieren'=>'Wenn der andere nach außen stabil wirkt — und du weißt, dass es nicht so ist.',
  'p2-b-dosierung'=>'Das richtige Maß beim Begleiten — weder schieben noch aufhalten.',
  'p2-b-hilflosigkeit'=>'Wenn du nichts tun kannst außer da zu sein — und warum das genug ist.',
  'p2-b-alltag'=>'Wie du unterstützt, ohne dich selbst dabei zu verlieren.',
  'p2-b-normalitaet'=>'Gemeinsam normal sein — wann hilft das, wann schadet es?',
  'p2-b-schwanger'=>'Wenn du oder eine andere Freundin schwanger ist — was tun?',
  'p2-b-therapie'=>'Professionelle Hilfe empfehlen — ohne Druck, ohne Vorwurf.',
  'p2-b-selbsthilfe'=>'Zur Selbsthilfegruppe begleiten — ohne zu schieben.',
  'p3-b-sprache'=>'Konkrete Formulierungen — und wann Schweigen mehr hilft als Worte.',
  'p3-b-partner'=>'Wenn du selbst betroffen bist und gleichzeitig begleitest.',
  'p3-b-freundschaft'=>'Wenn du nicht weißt, ob du noch gefragt bist — und wie du bleibst.',
  'p3-b-beruf'=>'Wie du im beruflichen Umfeld reagierst, wenn jemand zurückkommt.',
  'p3-b-zeitdruck'=>'Wann und wie du einen alten Verlust ansprechen kannst — ohne zu verletzen.',
  'p3-b-grenzen'=>'Wie du da bist, ohne die Grenzen des anderen zu überschreiten.',
  'p4-b-erinnerung'=>'Wie du das Kind, das du nie getroffen hast, trotzdem würdigst.',
  'p4-b-jahrestage'=>'Was du an Jahrestagen sagen oder tun kannst — und was hilft.',
  'p4-b-humor'=>'Wann und wie du auch mal lachen kannst, ohne zu verletzen.',
];

// ── WORDPRESS-ABFRAGE ─────────────────────────────────────────────────────────
// Alle veröffentlichten leitpfad-Posts einmal laden,
// dann per Titel zuordnen. get_permalink() gibt automatisch
// die richtige URL zurück — egal ob /pfad-a/... oder /pfad-b/...
$ltj_all_posts = get_posts([
  'post_type'      => 'leitpfad',
  'post_status'    => 'publish',
  'posts_per_page' => -1,
  'no_found_rows'  => true,
]);

// Titel → Post-Objekt Lookup (normalisiert: lowercase, trimmed)
$ltj_by_title = [];
foreach ( $ltj_all_posts as $p ) {
  $normalized = strtolower( trim( $p->post_title ) );
  $ltj_by_title[ $normalized ] = $p;
}

// Quiz-Artikel-Daten zusammenbauen
$ltj_article_data = [];
foreach ( $ltj_titles as $quiz_key => $title ) {
  $normalized = strtolower( trim( $title ) );
  if ( ! isset( $ltj_by_title[ $normalized ] ) ) continue;

  $post = $ltj_by_title[ $normalized ];
  setup_postdata( $post );

  $excerpt = has_excerpt( $post->ID )
    ? wp_trim_words( get_the_excerpt( $post->ID ), 18, '…' )
    : ( $ltj_fallback_desc[ $quiz_key ] ?? '' );

  $ltj_article_data[ $quiz_key ] = [
    'title' => get_the_title( $post->ID ),
    'desc'  => $excerpt,
    'url'   => get_permalink( $post->ID ),
    'tag'   => $ltj_tags[ $quiz_key ] ?? '',
  ];
}
wp_reset_postdata();
?>

<section class="ltj-quiz" id="orientierung">
  <div class="ltj-quiz__inner">
    <div class="ltj-quiz__head reveal">
      <div class="section-eyebrow">Geführte Orientierung</div>
      <h2 class="section-title ltj-quiz__title">Wo stehst du<br><em>gerade?</em></h2>
      <p class="ltj-quiz__intro">Beantworte drei kurze Fragen — du bekommst sofort die Artikel, die zu deiner Situation passen.</p>
    </div>
    <div class="ltj-quiz__box" id="ltjQuiz">
      <div class="ltj-quiz__progress">
        <span class="ltj-quiz__dot ltj-quiz__dot--active" data-step="1"></span>
        <span class="ltj-quiz__dash"></span>
        <span class="ltj-quiz__dot" data-step="2"></span>
        <span class="ltj-quiz__dash"></span>
        <span class="ltj-quiz__dot" data-step="3"></span>
      </div>
      <!-- Schritt 1 -->
      <div class="ltj-quiz__step" id="ltjStep1">
        <div class="ltj-quiz__step-label">Schritt 1 von 3</div>
        <h3 class="ltj-quiz__question">Wie bist du hier gelandet?</h3>
        <p class="ltj-quiz__sub">Damit ich dir die richtigen Artikel zeigen kann — sag mir kurz, in welcher Rolle du bist.</p>
        <div class="ltj-quiz__options">
          <button type="button" class="ltj-quiz__option" data-key="role" data-val="pfadA">
            <span class="ltj-quiz__option-icon">◈</span>
            <span class="ltj-quiz__option-text">Ich habe selbst einen Verlust erlebt</span>
          </button>
          <button type="button" class="ltj-quiz__option" data-key="role" data-val="pfadB">
            <span class="ltj-quiz__option-icon">◇</span>
            <span class="ltj-quiz__option-text">Ich begleite jemanden in seiner Trauer</span>
          </button>
        </div>
      </div>
      <!-- Schritt 2 -->
      <div class="ltj-quiz__step ltj-quiz__step--hidden" id="ltjStep2">
        <div class="ltj-quiz__step-label">Schritt 2 von 3</div>
        <h3 class="ltj-quiz__question">Wie lange ist der Verlust schon her?</h3>
        <p class="ltj-quiz__sub">Es geht nicht um eine genaue Zahl — sondern um das Gefühl, wo du gerade stehst.</p>
        <div class="ltj-quiz__options">
          <button type="button" class="ltj-quiz__option" data-key="time" data-val="akut">
            <span class="ltj-quiz__option-icon">●</span>
            <span class="ltj-quiz__option-text">Wir befinden uns gerade mittendrin — Krankenhaus, Beerdigung, erste Tage</span>
          </button>
          <button type="button" class="ltj-quiz__option" data-key="time" data-val="monate">
            <span class="ltj-quiz__option-icon">◐</span>
            <span class="ltj-quiz__option-text">Einige Wochen oder Monate sind vergangen</span>
          </button>
          <button type="button" class="ltj-quiz__option" data-key="time" data-val="laenger">
            <span class="ltj-quiz__option-icon">○</span>
            <span class="ltj-quiz__option-text">Es ist schon länger her — aber die Trauer ist geblieben</span>
          </button>
        </div>
        <button type="button" class="ltj-quiz__back" data-action="back" data-step="1">← Zurück</button>
      </div>
      <!-- Schritt 3 -->
      <div class="ltj-quiz__step ltj-quiz__step--hidden" id="ltjStep3">
        <div class="ltj-quiz__step-label">Schritt 3 von 3</div>
        <h3 class="ltj-quiz__question">Was bewegt dich gerade am meisten?</h3>
        <p class="ltj-quiz__sub">Wähle das, was sich momentan am stärksten anfühlt.</p>
        <div class="ltj-quiz__options" id="ltjStep3Options"></div>
        <button type="button" class="ltj-quiz__back" data-action="back" data-step="2">← Zurück</button>
      </div>
      <!-- Ergebnisse -->
      <div class="ltj-quiz__step ltj-quiz__step--hidden" id="ltjResults">
        <div class="ltj-quiz__results-head">
          <div class="ltj-quiz__step-label">Deine Empfehlungen</div>
          <h3 class="ltj-quiz__question">Das könnte dir gerade am meisten geben</h3>
          <p class="ltj-quiz__sub">Diese Artikel sind auf deine Situation zugeschnitten.</p>
        </div>
        <div class="ltj-quiz__cards" id="ltjCards"></div>
        <div class="ltj-quiz__result-actions">
          <button type="button" class="ltj-quiz__back" data-action="reset">← Neu starten</button>
        </div>
      </div>
    </div>
  </div>
</section>


<?php
if ( wp_script_is( 'thilo-quiz', 'enqueued' ) ) {
    wp_add_inline_script(
        'thilo-quiz',
        'window.thiloQuizData = ' . wp_json_encode(
            [
                'articleData' => $ltj_article_data,
            ],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        ) . ';',
        'before'
    );
}
?>
