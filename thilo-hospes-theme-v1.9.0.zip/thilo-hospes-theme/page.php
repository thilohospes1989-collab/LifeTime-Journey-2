<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>


<section class="post-hero post-hero--compact">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="post-hero-inner">
    <div class="post-eyebrow reveal">Seite</div>
    <h1 class="post-title reveal stagger-1"><?php the_title(); ?></h1>
  </div>
</section>

<article class="post-body page-body" id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
  <?php the_content(); ?>
</article>

<?php endwhile; ?>

<?php get_footer(); ?>
