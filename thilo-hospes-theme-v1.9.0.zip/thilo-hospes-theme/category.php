<?php get_header(); ?>

<?php
$cat  = get_queried_object();
$name = $cat->name;
$desc = $cat->description;
?>


<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Kategorie</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html($name); ?></h1>
    <?php if ( $desc ) : ?>
      <p class="archive-desc archive-desc--narrow reveal stagger-2">
        <?php echo esc_html($desc); ?>
      </p>
    <?php endif; ?>
  </div>
</section>

<div class="archive-grid">
  <?php $i = 0; if ( have_posts() ) : while ( have_posts() ) : the_post(); $i++;
    $lesezeit = get_post_meta( get_the_ID(), '_lesezeit', true );
    $pfad     = thilo_get_pfad_label();
    $phase    = thilo_get_phase_label();
  ?>
    <a class="archive-card reveal stagger-<?php echo ( $i % 3 ) + 1; ?>"
       href="<?php echo esc_url(get_permalink()); ?>">
      <?php if ( has_post_thumbnail() ) : ?>
        <div class="archive-card-thumb">
          <?php the_post_thumbnail('medium', ['loading'=>'lazy']); ?>
        </div>
      <?php endif; ?>
      <div class="archive-card-content">
        <?php $cats = get_the_category(); if ( $cats ) : ?>
          <div class="archive-card-phase"><?php echo esc_html($cats[0]->name); ?></div>
        <?php endif; ?>
        <h2 class="archive-card-title"><?php echo esc_html(get_the_title()); ?></h2>
        <?php if ( has_excerpt() ) : ?>
          <p class="archive-card-excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
        <?php endif; ?>
        <div class="archive-card-meta">
          <?php echo esc_html(get_the_date('d.m.Y')); ?>
          <?php if ($lesezeit) echo ' · ' . absint($lesezeit) . ' Min.'; ?>
        </div>
      </div>
    </a>
  <?php endwhile;
  else : ?>
    <div class="archive-empty">
      <p class="archive-empty-text">Noch keine Artikel in dieser Kategorie.</p>
    </div>
  <?php endif; ?>
</div>

<?php if ( $GLOBALS['wp_query']->max_num_pages > 1 ) : ?>
<div class="pagination-wrap">
  <?php the_posts_pagination([
    'mid_size'           => 2,
    'prev_text'          => '← Zurück',
    'next_text'          => 'Weiter →',
    'screen_reader_text' => ' ',
  ]); ?>
</div>
<?php endif; ?>

<?php get_footer(); ?>
