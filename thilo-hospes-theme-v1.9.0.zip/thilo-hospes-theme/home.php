<?php get_header(); ?>

<div class="home-index-wrap">
  <div class="section-eyebrow">Blog</div>
  <h1 class="section-title home-index-title">Alle Beiträge</h1>
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <article class="home-index-entry">
      <h2 class="home-index-entry-title">
        <a href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html(get_the_title()); ?></a>
      </h2>
      <p class="home-index-date"><?php echo esc_html(get_the_date()); ?></p>
      <div class="home-index-excerpt"><?php the_excerpt(); ?></div>
    </article>
  <?php endwhile; else : ?>
    <p class="home-index-empty">Noch keine Beiträge vorhanden.</p>
  <?php endif; ?>
</div>

<?php if ( $GLOBALS['wp_query']->max_num_pages > 1 ) : ?>
  <div class="pagination-wrap">
    <?php the_posts_pagination([
      'mid_size'           => 2,
      'prev_text'          => '← Zurück',
      'next_text'          => 'Weiter →',
      'screen_reader_text' => ' ',
    ]); ?>
  </div>
<?php endif; ?>

<?php get_footer(); ?>
