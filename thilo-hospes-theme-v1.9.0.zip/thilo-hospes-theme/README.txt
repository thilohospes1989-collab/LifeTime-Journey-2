Thilo Hospes Theme
==================

Package Summary
---------------
Theme Name: Thilo Hospes
Theme Slug: thilo-hospes-theme
Version: 1.7.7
Release Date: 2026-03-25
Maintainer: Thilo Hospes
Maintainer URI: https://www.thilo-hospes.de

Purpose
-------
Private custom WordPress theme package maintained for thilo-hospes.de.

Package Metadata Locations
--------------------------
- style.css: WordPress theme header and package notice
- functions.php: internal package constants for maintenance and release tracking
- COPYRIGHT.txt: authorship and copyright notice
- LICENSE.txt: license text and distribution note
- CHANGELOG.md: release history

Distribution Note
-----------------
This package is maintained as a private custom build. Any redistribution or reuse should only occur after checking the exact release contents and all applicable license obligations for WordPress core, code, media, fonts and any third-party assets.
