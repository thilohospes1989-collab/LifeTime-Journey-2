<?php get_header(); ?>
<?php
$term        = get_queried_object();
$pfad_filter = isset( $_GET['pfad'] ) ? sanitize_text_field( wp_unslash( $_GET['pfad'] ) ) : '';
$pfad_filter = in_array( $pfad_filter, [ 'a', 'b' ], true ) ? $pfad_filter : '';
$archive_url = thilo_get_leitpfad_selection_url();
$posts       = thilo_get_leitpfad_posts_for_phase( $term, $pfad_filter );
?>

<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Leitpfade · Phase</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html( $term->name ); ?></h1>
    <?php if ( ! empty( $term->description ) ) : ?>
      <p class="archive-desc reveal stagger-2"><?php echo esc_html( $term->description ); ?></p>
    <?php endif; ?>

    <div class="leitpfad-top-switch reveal stagger-3">
      <a href="<?php echo esc_url( get_term_link( $term ) ); ?>" class="leitpfad-top-pill <?php echo esc_attr( $pfad_filter === '' ? 'active' : '' ); ?>">
        <span class="leitpfad-top-pill-label">Alle</span>
        <span class="leitpfad-top-pill-sub">beide Pfade</span>
      </a>
      <a href="<?php echo esc_url( add_query_arg( 'pfad', 'a', get_term_link( $term ) ) ); ?>" class="leitpfad-top-pill <?php echo esc_attr( $pfad_filter === 'a' ? 'active' : '' ); ?>">
        <span class="leitpfad-top-pill-label">Pfad A</span>
        <span class="leitpfad-top-pill-sub">Betroffene</span>
      </a>
      <a href="<?php echo esc_url( add_query_arg( 'pfad', 'b', get_term_link( $term ) ) ); ?>" class="leitpfad-top-pill <?php echo esc_attr( $pfad_filter === 'b' ? 'active' : '' ); ?>">
        <span class="leitpfad-top-pill-label">Pfad B</span>
        <span class="leitpfad-top-pill-sub">Begleitende</span>
      </a>
    </div>

    <div class="archive-filters reveal stagger-4">
      <a href="<?php echo esc_url( $archive_url ); ?>" class="archive-filter-btn">Alle Leitpfade</a>
      <a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'a' ) ); ?>" class="archive-filter-btn">Pfad A</a>
      <a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'b' ) ); ?>" class="archive-filter-btn">Pfad B</a>
    </div>
  </div>
</section>

<div class="leitpfad-archive-wrap">
  <?php if ( $posts ) : ?>
    <section class="leitpfad-phase-block single-phase">
      <div class="leitpfad-card-grid">
        <?php foreach ( $posts as $post ) : setup_postdata( $post ); ?>
          <?php $lesezeit = get_post_meta( $post->ID, '_lesezeit', true ); ?>
          <article class="leitpfad-card pfad-<?php echo esc_attr( thilo_get_pfad_type( $post->ID ) ?: 'a' ); ?>">
            <a class="leitpfad-card-link" href="<?php echo esc_url( get_permalink( $post ) ); ?>"></a>
            <div class="leitpfad-card-badges">
              <?php if ( thilo_get_pfad_short_label( $post->ID ) ) : ?><span class="leitpfad-badge pfad"><?php echo esc_html( thilo_get_pfad_short_label( $post->ID ) ); ?></span><?php endif; ?>
              <span class="leitpfad-badge phase"><?php echo esc_html( $term->name ); ?></span>
              <?php if ( $lesezeit ) : ?><span class="leitpfad-badge meta"><?php echo absint( $lesezeit ); ?> Min.</span><?php endif; ?>
            </div>
            <h2 class="leitpfad-card-title"><?php echo esc_html( get_the_title( $post ) ); ?></h2>
            <p class="leitpfad-card-excerpt"><?php echo esc_html( thilo_get_leitpfad_excerpt( $post->ID ) ); ?></p>
          </article>
        <?php endforeach; wp_reset_postdata(); ?>
      </div>
    </section>
  <?php else : ?>
    <div class="leitpfad-empty">Noch keine Leitpfad-Artikel in dieser Phase.</div>
  <?php endif; ?>
</div>

<?php get_footer(); ?>
