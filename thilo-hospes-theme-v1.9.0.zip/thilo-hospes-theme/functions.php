<?php
/**
 * Theme bootstrap for the Thilo Hospes theme.
 *
 * Central package metadata is defined here. Functional code
 * is loaded from modular files in /inc for better maintainability.
 */

if ( ! defined( 'THILO_THEME_SLUG' ) ) {
    define( 'THILO_THEME_SLUG', 'thilo-hospes-theme' );
}

if ( ! defined( 'THILO_THEME_TEXTDOMAIN' ) ) {
    define( 'THILO_THEME_TEXTDOMAIN', 'thilo-hospes-theme' );
}

if ( ! defined( 'THILO_THEME_VERSION' ) ) {
    define( 'THILO_THEME_VERSION', '1.9.0' );
}

if ( ! defined( 'THILO_THEME_AUTHOR' ) ) {
    define( 'THILO_THEME_AUTHOR', 'Thilo Hospes' );
}

if ( ! defined( 'THILO_THEME_AUTHOR_URI' ) ) {
    define( 'THILO_THEME_AUTHOR_URI', 'https://www.thilo-hospes.de' );
}

if ( ! defined( 'THILO_THEME_COPYRIGHT_NOTICE' ) ) {
    define( 'THILO_THEME_COPYRIGHT_NOTICE', 'Copyright (C) 2026 Thilo Hospes' );
}

if ( ! defined( 'THILO_THEME_PACKAGE_URI' ) ) {
    define( 'THILO_THEME_PACKAGE_URI', 'https://www.thilo-hospes.de' );
}

if ( ! defined( 'THILO_THEME_RELEASE_DATE' ) ) {
    define( 'THILO_THEME_RELEASE_DATE', '2026-03-28' );
}

if ( ! defined( 'THILO_THEME_BUILD_ID' ) ) {
    define( 'THILO_THEME_BUILD_ID', 'thilo-hospes-theme|1.9.0|2026-03-28|private-release' );
}

$thilo_theme_includes = array(
    'inc/setup.php',
    'inc/post-types.php',
    'inc/admin.php',
    'inc/routing.php',
    'inc/helpers.php',
    'inc/meta-boxes.php',
    'inc/customizer.php',
    'inc/breadcrumbs.php',
    'inc/seo.php',
    'inc/acf.php',
    'inc/content.php',
    'inc/faq.php',
    'inc/frontend.php',
    'inc/health.php',
);

foreach ( $thilo_theme_includes as $thilo_theme_include ) {
    $thilo_theme_include_path = get_template_directory() . '/' . $thilo_theme_include;

    if ( file_exists( $thilo_theme_include_path ) ) {
        require_once $thilo_theme_include_path;
    }
}
