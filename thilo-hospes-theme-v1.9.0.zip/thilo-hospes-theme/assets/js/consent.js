/* Thilo Hospes Theme — Cookie Consent + Analytics */
(function () {
  var config = window.thiloConsentConfig || {};
  var bannerEnabled = Boolean(config.bannerEnabled);
  var gaId = typeof config.gaId === 'string' ? config.gaId.trim() : '';

  function loadGA() {
    if (!gaId || window.thiloGaLoaded) {
      return;
    }

    window.thiloGaLoaded = true;

    var script = document.createElement('script');
    script.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(gaId);
    script.async = true;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];

    function gtag() {
      window.dataLayer.push(arguments);
    }

    window.gtag = window.gtag || gtag;
    window.gtag('js', new Date());
    window.gtag('config', gaId, {
      anonymize_ip: true,
      cookie_flags: 'SameSite=None;Secure'
    });
  }

  if (localStorage.getItem('thilo_cookie_consent') === 'accepted') {
    loadGA();
  }

  document.addEventListener('thilo_cookie_accepted', loadGA);

  if (!bannerEnabled) {
    return;
  }

  var banner = document.getElementById('cookieBanner');
  if (!banner) {
    return;
  }

  if (!localStorage.getItem('thilo_cookie_consent')) {
    window.setTimeout(function () {
      banner.classList.add('visible');
    }, 800);
  }

  function hideBanner() {
    banner.classList.remove('visible');
    window.setTimeout(function () {
      banner.classList.add('is-hidden');
    }, 320);
  }

  var btnAccept = document.getElementById('cookieAccept');
  var btnDecline = document.getElementById('cookieDecline');

  if (btnAccept) {
    btnAccept.addEventListener('click', function () {
      localStorage.setItem('thilo_cookie_consent', 'accepted');
      hideBanner();
      document.dispatchEvent(new Event('thilo_cookie_accepted'));
    });
  }

  if (btnDecline) {
    btnDecline.addEventListener('click', function () {
      localStorage.setItem('thilo_cookie_consent', 'declined');
      hideBanner();
    });
  }
})();
