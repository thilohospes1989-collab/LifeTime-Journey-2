(function() {
	if (typeof tinymce === 'undefined') {
		return;
	}

	tinymce.create('tinymce.plugins.thiloLeitgedanke', {
		init: function(editor) {
			editor.addButton('thilo_leitgedanke', {
				text: 'Leitgedanke',
				tooltip: 'Leitgedanke einfügen',
				onclick: function() {
					var selectedContent = editor.selection.getContent({ format: 'html' });
					var hasSelection = selectedContent && selectedContent.replace(/<[^>]*>/g, '').trim().length > 0;

					if (hasSelection) {
						editor.selection.setContent(
							'[ltj_leitgedanke]\n' +
							selectedContent +
							'\n[/ltj_leitgedanke]'
						);
						return;
					}

					editor.insertContent(
						'[ltj_leitgedanke]\n' +
						'<p>Dein Leitgedanke hier ...</p>' +
						'\n[/ltj_leitgedanke]'
					);
				}
			});
		}
	});

	tinymce.PluginManager.add('thilo_leitgedanke', tinymce.plugins.thiloLeitgedanke);
})();
