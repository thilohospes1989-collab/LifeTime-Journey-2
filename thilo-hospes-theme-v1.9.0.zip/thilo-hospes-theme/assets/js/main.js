/* Thilo Hospes Theme — Main JS */
(function () {

  
  // Scroll reveal with IntersectionObserver
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  
  document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale').forEach(el => observer.observe(el));
  
  
  // Nav shrink + directional edge blur on scroll
  const nav = document.getElementById('site-nav');
  if (nav) {
    const body = document.body;
    const scrollIdleDelay = 140;
    let lastScrollY = window.scrollY;
    let scrollStopTimer = null;

    const clearScrollDirection = () => {
      body.classList.remove('scroll-dir-down', 'scroll-dir-up');
    };

    const updateScrollState = () => {
      const scrollY = window.scrollY;
      const maxScroll = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - window.innerHeight;
      const delta = scrollY - lastScrollY;

      if (scrollY > 60) {
        document.documentElement.style.setProperty('--nav-current-h', '50px');
        nav.style.borderBottomColor = 'rgba(184,146,58,0.25)';
      } else {
        document.documentElement.style.setProperty('--nav-current-h', '58px');
        nav.style.borderBottomColor = 'rgba(184,146,58,0.16)';
      }

      clearScrollDirection();
      window.clearTimeout(scrollStopTimer);

      if (scrollY <= 10 || maxScroll <= 0 || Math.abs(delta) < 2) {
        lastScrollY = scrollY;
        return;
      }

      if (delta > 0) {
        body.classList.add('scroll-dir-down');
      } else if (delta < 0 && scrollY < maxScroll - 10) {
        body.classList.add('scroll-dir-up');
      }

      scrollStopTimer = window.setTimeout(clearScrollDirection, scrollIdleDelay);
      lastScrollY = scrollY;
    };

    updateScrollState();
    window.addEventListener('scroll', updateScrollState, { passive: true });
  }
  

  const nums = document.querySelectorAll('.theme-num');
  const numObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animation = 'fadeUp 0.6s cubic-bezier(.22,1,.36,1) both';
        numObs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });
  nums.forEach(n => numObs.observe(n));
  


  // ─── Inhaltsverzeichnis nach erstem Bild positionieren ─────────────────────
  (function() {
    var tocWrap = document.getElementById('toc-wrap');
    var body    = document.querySelector('.post-body');
    if (!tocWrap || !body) return;
    var firstImg = body.querySelector('img, figure');
    if (firstImg) {
      var parent = firstImg.closest('figure') || firstImg.parentNode;
      parent.after(tocWrap);
    }
  })();

  // ─── Inhaltsverzeichnis ───────────────────────────────────────────────────
  (function() {
    var wrap    = document.getElementById('toc-wrap');
    var list    = document.getElementById('tocList');
    var toggle  = document.getElementById('tocToggle');
    var body    = document.querySelector('.post-body');
    if (!wrap || !list || !body) return;

    // Collect all h2 and h3 from post
    var headings = body.querySelectorAll('h2, h3');
    if (headings.length < 2) return; // hide if less than 2 headings

    var h2count = 0;
    headings.forEach(function(h, i) {
      // Add ID to heading
      var id = 'toc-' + i;
      h.setAttribute('id', id);

      var li   = document.createElement('li');
      var a    = document.createElement('a');
      var num  = document.createElement('span');
      var text = document.createElement('span');

      a.href = '#' + id;
      if (h.tagName === 'H2') {
        h2count++;
        num.className  = 'toc-num';
        num.textContent = h2count + '.';
        li.className   = 'toc-h2';
      } else {
        num.className  = 'toc-num';
        num.textContent = '–';
        li.className   = 'toc-h3';
      }

      text.textContent = h.textContent;
      a.appendChild(num);
      a.appendChild(text);
      li.appendChild(a);
      list.appendChild(li);

      // Smooth scroll
      a.addEventListener('click', function(e) {
        e.preventDefault();
        h.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // offset for fixed nav
        setTimeout(function() { window.scrollBy(0, -70); }, 300);
      });
    });

    // Show TOC
    wrap.classList.add('is-visible');

    // Toggle open/close
    var isOpen = true;
    toggle.classList.add('open');
    toggle.addEventListener('click', function() {
      isOpen = !isOpen;
      list.className = isOpen ? 'toc-list' : 'toc-list collapsed';
      toggle.className = isOpen ? 'toc-toggle open' : 'toc-toggle';
    });

    // Highlight active heading on scroll
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        var id = entry.target.getAttribute('id');
        var link = list.querySelector('a[href="#' + id + '"]');
        if (!link) return;
        if (entry.isIntersecting) {
          list.querySelectorAll('a').forEach(function(a) { a.classList.remove('active'); });
          link.classList.add('active');
        }
      });
    }, { rootMargin: '-10% 0px -80% 0px' });

    headings.forEach(function(h) { observer.observe(h); });
  })();


  // Hero Pattern wird serverseitig via PHP gerendert (thilo_hero_pattern())

  // Back to top button
  (function() {
    const backToTop = document.getElementById('siteBackToTop');
    if (!backToTop) return;

    const toggleBackToTop = () => {
      if (window.scrollY > 520) {
        backToTop.classList.add('is-visible');
      } else {
        backToTop.classList.remove('is-visible');
      }
    };

    toggleBackToTop();
    window.addEventListener('scroll', toggleBackToTop, { passive: true });

    backToTop.addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  })();

})();
