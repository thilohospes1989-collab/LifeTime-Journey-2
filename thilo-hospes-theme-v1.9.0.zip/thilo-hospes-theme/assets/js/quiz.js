(function () {
  var A = (window.thiloQuizData && window.thiloQuizData.articleData) || {};

  var M = {
    'pfadA-akut-krankenhaus': ['a1-a', 'a3-a', 'p1-a-funktionieren'],
    'pfadA-akut-beerdigung': ['a2-a', 'a1-a', 'a3-a'],
    'pfadA-akut-zusammenbruch': ['a3-a', 'p1-a-funktionieren', 'a1-a'],
    'pfadA-monate-verstehen': ['p1-a-koerper', 'p1-a-schweigen', 'p1-a-widerspruch'],
    'pfadA-monate-funktionieren': ['p2-a-dosierung', 'p2-a-alltag', 'p1-a-funktionieren'],
    'pfadA-monate-umfeld': ['p2-a-vergleiche', 'p3-a-sprache', 'p2-a-schwanger'],
    'pfadA-monate-hilfe': ['p2-a-therapie', 'p2-a-selbsthilfe', 'p2-a-dosierung'],
    'pfadA-laenger-beziehungen': ['p3-a-partner', 'p3-a-freundschaft', 'p3-a-beruf'],
    'pfadA-laenger-druck': ['p3-a-zeitdruck', 'p2-a-normalitaet', 'p3-a-grenzen'],
    'pfadA-laenger-bleiben': ['p4-a-erinnerung', 'p4-a-jahrestage', 'p4-a-humor'],
    'pfadA-laenger-leichtigkeit': ['p4-a-humor', 'p2-a-normalitaet', 'p4-a-erinnerung'],
    'pfadB-akut-daneben': ['a1-b', 'a3-b', 'p1-b-schweigen'],
    'pfadB-akut-organisieren': ['a2-b', 'a1-b', 'p2-b-hilflosigkeit'],
    'pfadB-akut-zusammenbruch': ['a3-b', 'p1-b-signale', 'p2-b-hilflosigkeit'],
    'pfadB-monate-signale': ['p1-b-signale', 'p1-b-schweigen', 'p1-b-koerper'],
    'pfadB-monate-hilflos': ['p2-b-hilflosigkeit', 'p2-b-dosierung', 'p1-b-schweigen'],
    'pfadB-monate-selbst': ['p3-b-partner', 'p2-b-hilflosigkeit', 'p1-b-signale'],
    'pfadB-monate-hilfe': ['p2-b-therapie', 'p2-b-selbsthilfe', 'p2-b-dosierung'],
    'pfadB-laenger-dasein': ['p3-b-freundschaft', 'p3-b-zeitdruck', 'p3-b-grenzen'],
    'pfadB-laenger-beruf': ['p3-b-beruf', 'p3-b-sprache', 'p3-b-grenzen'],
    'pfadB-laenger-jahrestage': ['p4-b-jahrestage', 'p4-b-erinnerung', 'p3-b-zeitdruck'],
    'pfadB-laenger-leichtigkeit': ['p4-b-humor', 'p4-b-jahrestage', 'p3-b-grenzen']
  };

  var Q = {
    'pfadA-akut': [
      { v: 'krankenhaus', t: 'Ich bin im Krankenhaus oder kurz danach — ich weiß nicht, was gerade passiert' },
      { v: 'beerdigung', t: 'Ich muss funktionieren — Beerdigung, Organisieren, während ich innerlich zerfalle' },
      { v: 'zusammenbruch', t: 'Ich breche immer wieder zusammen und weiß nicht, was das bedeutet' }
    ],
    'pfadA-monate': [
      { v: 'verstehen', t: 'Ich verstehe nicht, was in mir vorgeht — Körper, Stille, Widersprüche' },
      { v: 'funktionieren', t: 'Ich kämpfe täglich ums Funktionieren — Alltag, Erschöpfung, keine Energie' },
      { v: 'umfeld', t: 'Mein Umfeld macht es schwerer — Sätze, Vergleiche, andere Reaktionen' },
      { v: 'hilfe', t: 'Ich frage mich, ob ich professionelle Hilfe brauche' }
    ],
    'pfadA-laenger': [
      { v: 'beziehungen', t: 'Meine Beziehungen haben sich verändert — Partner, Freunde, Arbeit' },
      { v: 'druck', t: 'Ich spüre Druck, endlich weiterzumachen — von innen oder außen' },
      { v: 'bleiben', t: 'Ich suche nach dem, was bleibt — Erinnerung, Rituale, Bindung' },
      { v: 'leichtigkeit', t: 'Darf ich auch mal lachen? Darf ich Leichtigkeit fühlen?' }
    ],
    'pfadB-akut': [
      { v: 'daneben', t: 'Ich stehe dabei und weiß nicht, was ich tun oder sagen soll' },
      { v: 'organisieren', t: 'Ich organisiere vieles — und merke, ich übernehme vielleicht zu viel' },
      { v: 'zusammenbruch', t: 'Derjenige bricht immer wieder zusammen — ich weiß nicht, wie ich helfen soll' }
    ],
    'pfadB-monate': [
      { v: 'signale', t: 'Ich verstehe die Signale nicht — Schweigen, Widersprüche, Körperreaktionen' },
      { v: 'hilflos', t: 'Ich fühle mich hilflos — ich weiß nicht, wie ich wirklich helfen soll' },
      { v: 'selbst', t: 'Ich selbst bin auch betroffen und weiß nicht, wie ich gleichzeitig begleiten soll' },
      { v: 'hilfe', t: 'Soll ich Therapie oder Selbsthilfe ansprechen?' }
    ],
    'pfadB-laenger': [
      { v: 'dasein', t: 'Ich weiß nicht, ob ich noch gefragt bin — wie ich da sein kann, ohne aufzudrängen' },
      { v: 'beruf', t: 'Im Job — wie verhalte ich mich richtig, wenn jemand zurückkommt?' },
      { v: 'jahrestage', t: 'Jahrestage und Erinnerungen — ansprechen oder schweigen?' },
      { v: 'leichtigkeit', t: 'Darf auch ich mal lachen oder leicht sein?' }
    ]
  };

  var S = { role: null, time: null };

  function step(n) {
    ['ltjStep1', 'ltjStep2', 'ltjStep3'].forEach(function (id, i) {
      var el = document.getElementById(id);
      if (el) {
        el.classList.toggle('ltj-quiz__step--hidden', i + 1 !== n);
      }
    });

    var results = document.getElementById('ltjResults');
    if (results) {
      results.classList.toggle('ltj-quiz__step--hidden', n !== 4);
    }

    document.querySelectorAll('.ltj-quiz__dot').forEach(function (dot) {
      var s = parseInt(dot.getAttribute('data-step'), 10);
      dot.classList.toggle('ltj-quiz__dot--active', s === n && n < 4);
      dot.classList.toggle('ltj-quiz__dot--done', s < n || (n === 4 && s <= 3));
    });
  }

  function makeOptionButton(text, value) {
    var button = document.createElement('button');
    var icon = document.createElement('span');
    var label = document.createElement('span');

    button.className = 'ltj-quiz__option';
    button.type = 'button';
    button.setAttribute('data-key', 'topic');
    button.setAttribute('data-val', value);

    icon.className = 'ltj-quiz__option-icon';
    icon.textContent = '✦';

    label.className = 'ltj-quiz__option-text';
    label.textContent = text;

    button.appendChild(icon);
    button.appendChild(label);

    return button;
  }

  function buildQ3() {
    var opts = Q[S.role + '-' + S.time] || [];
    var container = document.getElementById('ltjStep3Options');
    if (!container) {
      return;
    }

    container.innerHTML = '';
    opts.forEach(function (option) {
      container.appendChild(makeOptionButton(option.t, option.v));
    });
  }

  function buildResultCard(article, count) {
    var card = document.createElement('div');
    var number = document.createElement('div');
    var body = document.createElement('div');
    var tag = document.createElement('div');
    var title = document.createElement('div');
    var desc = document.createElement('div');
    var link = document.createElement('a');

    card.className = 'ltj-quiz__card';
    number.className = 'ltj-quiz__card-num';
    body.className = 'ltj-quiz__card-body';
    tag.className = 'ltj-quiz__card-tag';
    title.className = 'ltj-quiz__card-title';
    desc.className = 'ltj-quiz__card-desc';
    link.className = 'ltj-quiz__card-link';

    number.textContent = String(count);
    tag.textContent = article.tag || '';
    title.textContent = article.title || '';
    desc.textContent = article.desc || '';
    link.href = article.url || '#';
    link.textContent = 'Artikel lesen →';

    body.appendChild(tag);
    body.appendChild(title);
    body.appendChild(desc);
    body.appendChild(link);

    card.appendChild(number);
    card.appendChild(body);

    return card;
  }

  function buildEmptyState() {
    var empty = document.createElement('p');
    empty.className = 'ltj-quiz__empty';
    empty.textContent = 'Diese Artikel erscheinen hier, sobald sie veröffentlicht sind.';
    return empty;
  }

  function results(topic) {
    var keys = M[S.role + '-' + S.time + '-' + topic] || [];
    var container = document.getElementById('ltjCards');
    var quiz = document.getElementById('ltjQuiz');
    var count = 0;

    if (!container) {
      return;
    }

    container.innerHTML = '';

    keys.forEach(function (key) {
      var article = A[key];
      if (!article) {
        return;
      }

      count += 1;
      container.appendChild(buildResultCard(article, count));
    });

    if (!count) {
      container.appendChild(buildEmptyState());
    }

    step(4);
    if (quiz) {
      quiz.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function handleAnswer(button) {
    if (!button) {
      return;
    }

    var key = button.getAttribute('data-key');
    var value = button.getAttribute('data-val');

    if (key === 'role') {
      S.role = value;
      step(2);
    } else if (key === 'time') {
      S.time = value;
      buildQ3();
      step(3);
    } else if (key === 'topic') {
      results(value);
    }
  }

  function goBack(n) {
    step(n);
  }

  function resetQuiz() {
    var quiz = document.getElementById('ltjQuiz');
    S = { role: null, time: null };
    step(1);
    if (quiz) {
      quiz.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  document.addEventListener('click', function (event) {
    var answerButton = event.target.closest('.ltj-quiz__option[data-key]');
    if (answerButton) {
      handleAnswer(answerButton);
      return;
    }

    var actionButton = event.target.closest('[data-action]');
    if (!actionButton) {
      return;
    }

    var action = actionButton.getAttribute('data-action');
    if (action === 'back') {
      goBack(parseInt(actionButton.getAttribute('data-step'), 10) || 1);
    } else if (action === 'reset') {
      resetQuiz();
    }
  });

  document.addEventListener('DOMContentLoaded', function () {
    if (!document.getElementById('ltjQuiz')) {
      return;
    }

    step(1);
  });
})();
