/* Thilo Hospes Theme — Navigation */
(function () {
  const nav = document.getElementById('site-nav');
  const navToggle = document.getElementById('navToggle');
  const navMobile = document.getElementById('navMobile');

  if (!nav || !navToggle || !navMobile) {
    return;
  }

  let lockedScrollY = 0;

  function syncMobileMenuPosition() {
    const navRect = nav.getBoundingClientRect();
    const navBottom = Math.max(Math.round(navRect.bottom) - 1, 0);

    navMobile.style.top = navBottom + 'px';
    navMobile.style.height = 'calc(100dvh - ' + navBottom + 'px)';
  }

  function lockBodyScroll() {
    lockedScrollY = window.scrollY || window.pageYOffset || 0;
    document.body.style.position = 'fixed';
    document.body.style.top = '-' + lockedScrollY + 'px';
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
  }

  function unlockBodyScroll() {
    const scrollY = Math.abs(parseInt(document.body.style.top || '0', 10)) || lockedScrollY;

    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';

    window.scrollTo(0, scrollY);
  }

  function setMenuState(open) {
    if (open) {
      syncMobileMenuPosition();
    }

    navToggle.classList.toggle('open', open);
    navMobile.classList.toggle('open', open);
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    navMobile.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('mobile-menu-open', open);

    if (open) {
      lockBodyScroll();
      syncMobileMenuPosition();
    } else {
      unlockBodyScroll();
    }
  }

  function toggleMenu(event) {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }

    setMenuState(!navMobile.classList.contains('open'));
  }

  navToggle.addEventListener('click', toggleMenu);

  navMobile.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
      setMenuState(false);
    });
  });

  document.addEventListener('click', function (event) {
    if (!navMobile.classList.contains('open')) {
      return;
    }

    if (navMobile.contains(event.target) || navToggle.contains(event.target)) {
      return;
    }

    setMenuState(false);
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && navMobile.classList.contains('open')) {
      setMenuState(false);
    }
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth > 960 && navMobile.classList.contains('open')) {
      setMenuState(false);
      return;
    }

    syncMobileMenuPosition();
  });

  window.addEventListener('orientationchange', function () {
    window.setTimeout(syncMobileMenuPosition, 50);
  });

  window.addEventListener('load', syncMobileMenuPosition);
  syncMobileMenuPosition();
  setMenuState(false);
})();
