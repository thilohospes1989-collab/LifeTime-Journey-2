<?php
$themenbereiche_url = thilo_get_themenbereiche_page_url();
$leitpfad_url       = thilo_get_leitpfad_selection_url();
$leitpfad_archiv_url = thilo_get_leitpfad_archive_url();
$about_url          = thilo_get_about_page_url();
$impressum_url      = thilo_get_legal_page_url( 'impressum' );
$datenschutz_url    = thilo_get_legal_page_url( 'datenschutz' );
$kontakt_url        = thilo_get_legal_page_url( 'kontakt' );
?>
<footer>
  <div class="footer-brand">
    <div class="footer-logo-wrap">
      <?php
      if ( has_custom_logo() ) {
          $logo = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' );
          if ( $logo ) {
              echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
          }
      }
      ?>
    </div>
    <div class="footer-brand-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
    <p class="footer-tagline"><?php esc_html_e( 'Schwere Dinge tragen — und trotzdem wachsen.', 'thilo-hospes-theme' ); ?></p>
    <div class="footer-social">
      <a href="<?php echo esc_url( get_theme_mod( 'thilo_youtube_url', 'https://youtube.com/@thilohospes' ) ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr__( 'YouTube', 'thilo-hospes-theme' ); ?>">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
      </a>
    </div>
  </div>

  <div>
    <div class="footer-col-title"><?php esc_html_e( 'Navigation', 'thilo-hospes-theme' ); ?></div>
    <ul class="footer-links">
      <li><a href="<?php echo esc_url( $themenbereiche_url ); ?>"><?php esc_html_e( 'Themenbereiche', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( $leitpfad_url ); ?>"><?php esc_html_e( 'Leitpfade', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( $leitpfad_archiv_url ); ?>"><?php esc_html_e( 'Leitpfad-Archiv', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( $about_url ); ?>"><?php esc_html_e( 'Über mich', 'thilo-hospes-theme' ); ?></a></li>
    </ul>
  </div>

  <div>
    <div class="footer-col-title"><?php esc_html_e( 'Leitpfade', 'thilo-hospes-theme' ); ?></div>
    <ul class="footer-links">
      <li><a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'a' ) ); ?>"><?php esc_html_e( 'Pfad A — Betroffene', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'b' ) ); ?>"><?php esc_html_e( 'Pfad B — Begleitende', 'thilo-hospes-theme' ); ?></a></li>
    </ul>
  </div>

  <div>
    <div class="footer-col-title"><?php esc_html_e( 'Rechtliches', 'thilo-hospes-theme' ); ?></div>
    <ul class="footer-links">
      <li><a href="<?php echo esc_url( $impressum_url ); ?>"><?php esc_html_e( 'Impressum', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( $datenschutz_url ); ?>"><?php esc_html_e( 'Datenschutz', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url( $kontakt_url ); ?>"><?php esc_html_e( 'Kontakt', 'thilo-hospes-theme' ); ?></a></li>
    </ul>
  </div>

  <div class="footer-bottom">
    <p>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?> · </p>
    <p><?php esc_html_e( 'Umgesetzt mit Herz, Schmerz und sehr viel Kaffee.', 'thilo-hospes-theme' ); ?></p>
  </div>
</footer>

<button type="button" class="site-back-to-top" id="siteBackToTop" aria-label="Nach oben scrollen">
  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M12 19V5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
    <path d="M6.75 10.25 12 5l5.25 5.25" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
</button>

<?php wp_footer(); ?>
</body>
</html>
