<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<?php
$lesezeit = get_post_meta( get_the_ID(), '_lesezeit', true );
$cats     = get_the_category();
$prev     = get_previous_post();
$next     = get_next_post();
?>

<section class="post-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="post-hero-inner">
    <h1 class="post-hero-title reveal stagger-1"><?php echo esc_html( get_the_title() ); ?></h1>

    <?php thilo_breadcrumbs(); ?>

    <div class="post-hero-eyebrow reveal">
      <?php if ( $cats ) : ?>
        <a href="<?php echo esc_url( get_category_link( $cats[0]->term_id ) ); ?>" class="post-cat-badge"><?php echo esc_html( $cats[0]->name ); ?></a>
      <?php endif; ?>
      <?php if ( $lesezeit ) : ?>
        <span class="post-meta-sep"></span>
        <span class="post-readtime"><?php echo absint( $lesezeit ); ?> Min. Lesezeit</span>
      <?php endif; ?>
    </div>

    <div class="post-hero-meta reveal stagger-2">
      <div class="post-hero-author">
        <?php echo get_avatar( get_the_author_meta( 'user_email' ), 32, '', '', [ 'class' => 'post-author-avatar' ] ); ?>
        <span><?php the_author(); ?></span>
      </div>
      <span class="post-meta-sep"></span>
      <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'd. F Y' ) ); ?></time>
    </div>
  </div>
</section>

<article class="post-body" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

  <?php if ( has_post_thumbnail() ) : ?>
    <div class="post-thumbnail">
      <?php the_post_thumbnail( 'large', [ 'class' => 'post-thumbnail-image', 'loading' => 'eager' ] ); ?>
    </div>
  <?php endif; ?>

  <div class="toc-wrap" id="toc-wrap">
    <div class="toc-inner">
      <div class="toc-header">
        <span class="toc-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </span>
        <span class="toc-title">Inhaltsverzeichnis</span>
        <button class="toc-toggle" id="tocToggle" aria-label="Inhaltsverzeichnis ein/ausklappen" aria-expanded="true" aria-controls="tocList">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
      </div>
      <ol class="toc-list" id="tocList"></ol>
    </div>
  </div>

  <div class="post-content">
    <?php the_content(); ?>
  </div>

  <?php thilo_render_post_faq_section( get_the_ID() ); ?>

</article>

<nav class="post-nav" aria-label="Artikel Navigation">
  <?php if ( $prev ) : ?>
    <a class="post-nav-item post-nav-item--prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
      <div class="post-nav-label">← Vorheriger Artikel</div>
      <div class="post-nav-title"><?php echo esc_html( get_the_title( $prev ) ); ?></div>
    </a>
  <?php else : ?>
    <div class="post-nav-item post-nav-item--empty"></div>
  <?php endif; ?>

  <?php if ( $next ) : ?>
    <a class="post-nav-item post-nav-item--next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
      <div class="post-nav-label">Nächster Artikel →</div>
      <div class="post-nav-title"><?php echo esc_html( get_the_title( $next ) ); ?></div>
    </a>
  <?php else : ?>
    <div class="post-nav-item post-nav-item--empty"></div>
  <?php endif; ?>
</nav>

<?php endwhile; ?>

<?php get_footer(); ?>
