<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
$themes_page  = get_page_by_path('themenbereiche');
$themes_url   = $themes_page ? get_permalink($themes_page) : home_url('/themenbereiche/');
$leitpfad_url = thilo_get_leitpfad_selection_url();
$blog_url     = thilo_get_posts_page_url();
$books_url    = thilo_get_books_page_url();
$mobile_menu_location = has_nav_menu('mobile') ? 'mobile' : 'primary';
?>

<nav id="site-nav">

  <a class="nav-logo" href="<?php echo esc_url(home_url('/')); ?>">
    <div class="nav-logo-wrap">
      <?php
      if ( has_custom_logo() ) {
          $logo = wp_get_attachment_image_src( get_theme_mod('custom_logo'), 'full' );
          if ( $logo ) echo '<img src="' . esc_url($logo[0]) . '" alt="' . esc_attr(get_bloginfo('name')) . '">';
      }
      ?>
    </div>
    <div class="nav-brand">
      <span class="nav-brand-name"><?php
        $name = get_bloginfo('name');
        // Highlight everything after " – " or " - " in gold
        if ( strpos($name, ' – ') !== false ) {
            list($before, $after) = explode(' – ', $name, 2);
            echo esc_html($before) . ' <span class="nav-brand-accent">– ' . esc_html($after) . '</span>';
        } elseif ( strpos($name, ' - ') !== false ) {
            list($before, $after) = explode(' - ', $name, 2);
            echo esc_html($before) . ' <span class="nav-brand-accent">– ' . esc_html($after) . '</span>';
        } else {
            echo esc_html($name);
        }
      ?></span>
    </div>
  </a>

  <div class="nav-desktop-menu">
    <?php if ( has_nav_menu('primary') ) :
      wp_nav_menu([
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'nav-links',
        'fallback_cb'    => false,
      ]);
    else : ?>
    <ul class="nav-links">
      <li><a href="<?php echo esc_url($books_url); ?>"><?php esc_html_e( 'Bücher', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url($themes_url); ?>"><?php esc_html_e( 'Themenbereiche', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url($blog_url); ?>"><?php esc_html_e( 'Neueste Beiträge', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url(home_url('/#youtube')); ?>"><?php esc_html_e( 'YouTube', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url(home_url('/#about-me')); ?>"><?php esc_html_e( 'Über mich', 'thilo-hospes-theme' ); ?></a></li>
      <li><a href="<?php echo esc_url($leitpfad_url); ?>"><?php esc_html_e( 'Leitpfade', 'thilo-hospes-theme' ); ?></a></li>
    </ul>
    <?php endif; ?>
  </div>

  <button type="button" class="nav-hamburger" id="navToggle" aria-label="<?php echo esc_attr__( 'Menü öffnen', 'thilo-hospes-theme' ); ?>" aria-expanded="false" aria-controls="navMobile">
    <span></span><span></span><span></span>
  </button>

</nav>

<div class="nav-mobile-menu" id="navMobile" aria-hidden="true">
  <?php if ( has_nav_menu($mobile_menu_location) ) :
    wp_nav_menu([
      'theme_location' => $mobile_menu_location,
      'container'      => false,
      'menu_class'     => 'nav-mobile-list',
      'fallback_cb'    => false,
    ]);
  else : ?>
  <ul class="nav-mobile-list">
    <li><a href="<?php echo esc_url($books_url); ?>"><?php esc_html_e( 'Bücher', 'thilo-hospes-theme' ); ?></a></li>
    <li><a href="<?php echo esc_url($themes_url); ?>"><?php esc_html_e( 'Themenbereiche', 'thilo-hospes-theme' ); ?></a></li>
    <li><a href="<?php echo esc_url($blog_url); ?>"><?php esc_html_e( 'Neueste Beiträge', 'thilo-hospes-theme' ); ?></a></li>
    <li><a href="<?php echo esc_url(home_url('/#youtube')); ?>"><?php esc_html_e( 'YouTube', 'thilo-hospes-theme' ); ?></a></li>
    <li><a href="<?php echo esc_url(home_url('/#about-me')); ?>"><?php esc_html_e( 'Über mich', 'thilo-hospes-theme' ); ?></a></li>
    <li><a href="<?php echo esc_url($leitpfad_url); ?>"><?php esc_html_e( 'Leitpfade', 'thilo-hospes-theme' ); ?></a></li>
  </ul>
  <?php endif; ?>
</div>

