<?php get_header(); ?>


<section class="archive-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="archive-hero-inner">
    <div class="section-eyebrow reveal">Suche</div>
    <h1 class="section-title reveal stagger-1">
      <?php if ( have_posts() ) : ?>
        Ergebnisse für <em class="search-query-highlight">&bdquo;<?php echo esc_html( get_search_query() ); ?>&ldquo;</em>
      <?php else : ?>
        Keine Ergebnisse für &bdquo;<?php echo esc_html( get_search_query() ); ?>&ldquo;
      <?php endif; ?>
    </h1>
    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form-inline">
      <input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Erneut suchen …" class="search-form-inline-input">
      <button type="submit" class="search-form-inline-button">Suchen</button>
    </form>
  </div>
</section>

<div class="archive-grid">
  <?php if ( have_posts() ) : $i = 0; while ( have_posts() ) : the_post(); $i++; ?>
    <?php
    $post_type = get_post_type();
    $lesezeit  = get_post_meta( get_the_ID(), '_lesezeit', true );
    $meta_line = '';

    if ( $post_type === 'leitpfad' ) {
        $phase_label = thilo_get_phase_label( get_the_ID() );
        $pfad_label  = thilo_get_pfad_label( get_the_ID() );
        $meta_line   = trim( implode( ' · ', array_filter( [ $phase_label, $pfad_label ] ) ) );
    } elseif ( $post_type === 'post' ) {
        $cats = get_the_category();
        $meta_line = $cats ? $cats[0]->name : 'Beitrag';
    } elseif ( $post_type === 'page' ) {
        $meta_line = 'Seite';
    } elseif ( $post_type === 'buch' ) {
        $meta_line = 'Buch';
    } else {
        $meta_line = ucfirst( $post_type );
    }
    ?>
    <a class="archive-card reveal stagger-<?php echo ( $i % 4 ) + 1; ?>" href="<?php echo esc_url( get_permalink() ); ?>">
      <?php if ( $meta_line ) : ?><div class="archive-card-phase"><?php echo esc_html( $meta_line ); ?></div><?php endif; ?>
      <h2 class="archive-card-title"><?php echo esc_html( get_the_title() ); ?></h2>
      <p class="archive-card-excerpt"><?php echo esc_html( has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 28, ' …' ) ); ?></p>
      <div class="archive-card-meta">
        <?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?>
        <?php if ( $lesezeit ) : ?> · <?php echo absint( $lesezeit ); ?> Min.<?php endif; ?>
      </div>
    </a>
  <?php endwhile; else : ?>
    <div class="archive-empty">
      <p class="archive-empty-text archive-empty-text--spaced">Keine Artikel gefunden. Versuch es mit anderen Suchbegriffen.</p>
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn-ghost">Zur Startseite</a>
    </div>
  <?php endif; ?>
</div>

<?php get_footer(); ?>
