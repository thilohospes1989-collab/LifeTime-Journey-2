<?php
/*
 * Template Name: Themenbereiche
 */
get_header();
?>


<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Übersicht</div>
    <h1 class="section-title reveal stagger-1">Themenbereiche</h1>
    <p class="archive-desc reveal stagger-2">Alle Kategorien im Überblick — wähle ein Thema und sieh alle zugehörigen Artikel.</p>
  </div>
</section>

<div class="themenbereiche-wrap">
  <div class="themes-grid">
    <?php
    $categories = get_categories([
        'orderby'    => 'name',
        'order'      => 'ASC',
        'hide_empty' => false,
        'exclude'    => thilo_get_default_category_id(),
    ]);
    $i = 0;
    foreach ( $categories as $cat ) :
        $i++;
        $count            = (int) $cat->count;
        $count_label      = $count === 1 ? '1 Artikel' : $count . ' Artikel';
        $card_description = trim( wp_strip_all_tags( $cat->description ) );
        if ( '' === $card_description ) {
            $card_description = $count > 0
                ? $count_label . ' in diesem Themenbereich.'
                : 'Zur Kategorie öffnen.';
        }
    ?>
      <article class="leitpfad-card theme-card-exact reveal stagger-<?php echo ( $i % 3 ) + 1; ?>">
        <a class="leitpfad-card-link" href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"></a>
        <div class="leitpfad-card-badges">
          <span class="leitpfad-badge phase">Kategorie</span>
          <span class="leitpfad-badge meta"><?php echo esc_html( $count_label ); ?></span>
        </div>
        <h3 class="leitpfad-card-title"><?php echo esc_html( $cat->name ); ?></h3>
        <p class="leitpfad-card-excerpt"><?php echo esc_html( $card_description ); ?></p>
      </article>
    <?php endforeach; ?>
  </div>
</div>

<?php get_footer(); ?>
