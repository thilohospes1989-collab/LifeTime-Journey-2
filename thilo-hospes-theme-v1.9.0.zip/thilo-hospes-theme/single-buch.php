<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<?php
$cover_url  = get_post_meta( get_the_ID(), '_cover_url', true );
$cover_img  = $cover_url ?: get_the_post_thumbnail_url( get_the_ID(), 'large' );
$band_label = get_post_meta( get_the_ID(), '_band_label', true );
$untertitel = get_post_meta( get_the_ID(), '_untertitel', true );
$tag_label  = get_post_meta( get_the_ID(), '_tag_label', true ) ?: 'Jetzt bestellen';
$kauf_url   = get_post_meta( get_the_ID(), '_kauf_url', true );
?>


<section class="buch-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="buch-hero-inner">

    <div class="buch-hero-cover reveal-scale">
      <?php if ( $cover_img ) : ?>
        <img src="<?php echo esc_url($cover_img); ?>"
             alt="<?php the_title_attribute(); ?>"
             class="buch-hero-cover-image">
      <?php endif; ?>
    </div>

    <div class="buch-hero-content">
      <?php if ( $band_label ) : ?>
        <div class="post-eyebrow reveal"><?php echo esc_html($band_label); ?></div>
      <?php endif; ?>
      <h1 class="post-title reveal stagger-1"><?php echo esc_html(get_the_title()); ?></h1>
      <?php if ( $untertitel ) : ?>
        <p class="buch-hero-sub reveal stagger-2"><?php echo esc_html($untertitel); ?></p>
      <?php endif; ?>
      <?php if ( has_excerpt() ) : ?>
        <p class="buch-hero-desc reveal stagger-3"><?php echo esc_html(get_the_excerpt()); ?></p>
      <?php endif; ?>
      <div class="buch-hero-actions reveal stagger-4">
        <?php if ( $kauf_url ) : ?>
        <a href="<?php echo esc_url($kauf_url); ?>" class="btn-primary" target="_blank" rel="noopener"><?php echo esc_html($tag_label); ?></a>
        <?php else : ?>
        <span class="btn-primary btn-primary--disabled">Bald verfügbar</span>
        <?php endif; ?>
        <a href="<?php echo esc_url(thilo_get_books_page_url()); ?>" class="btn-ghost">Alle Bücher</a>
      </div>
    </div>

  </div>
</section>

<?php if ( get_the_content() ) : ?>
<div class="post-body post-body--bordered">
  <?php the_content(); ?>
</div>
<?php endif; ?>

<?php endwhile; ?>

<?php get_footer(); ?>
