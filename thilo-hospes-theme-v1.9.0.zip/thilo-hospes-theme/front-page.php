<?php get_header(); ?>
<?php
$hero_bild     = thilo_get_field_safe( 'hero_bild', '' );
$hero_eyebrow  = thilo_get_field_safe( 'hero_eyebrow', 'Mein Weg durch Schmerz, Heilung & Wachstum' );
$hero_titel_1  = thilo_get_field_safe( 'hero_titel', 'Schwere Dinge tragen —' );
$hero_titel_2  = thilo_get_field_safe( 'hero_titel2', 'und trotzdem' );
$hero_titel_3  = thilo_get_field_safe( 'hero_titel_gold', 'wachsen.' );
$hero_text     = thilo_get_field_safe( 'hero_text', 'Psychologie, Trauer und Traumatherapie — aufgeschrieben von jemandem, der diesen Weg selbst gegangen ist. Kein Lehrbuch, keine Floskeln. Erkenntnisse, Ehrlichkeit, Einblicke für andere Sternenkindeltern.' );
$hero_btn1     = thilo_get_field_safe( 'hero_btn1', 'Mehr erfahren' );
$hero_btn1_url = thilo_get_field_safe( 'hero_btn1_url', '#about-me' );
$hero_btn2     = thilo_get_field_safe( 'hero_btn2', 'Themenbereiche' );
$hero_btn2_url = thilo_get_field_safe( 'hero_btn2_url', '#themes' );

$about_name     = thilo_get_field_safe( 'about_name', 'Thilo Hospes' );
$about_rolle    = thilo_get_field_safe( 'about_rolle', 'Sternenkindvater & Autor' );
$about_bio      = thilo_get_field_safe( 'about_bio', '2011 verlor ich meine Tochter Katy-Lynn durch eine stille Geburt. In diesem Moment blieb meine Welt stehen. Ich bin kein Therapeut. Ich habe Trauer nicht studiert — ich habe sie gelebt. Und ich habe gelernt, was trägt.' );
$portrait_url   = thilo_get_field_safe( 'about_portrait', '' );
$themes_url     = thilo_get_themenbereiche_page_url();
$about_page_url = thilo_get_about_page_url();
$pfad_a_url     = thilo_get_pfad_archive_link( 'a' );
$pfad_b_url     = thilo_get_pfad_archive_link( 'b' );
$yt_url         = esc_url( get_theme_mod( 'thilo_youtube_url', 'https://youtube.com/@thilohospes-lifetimejourney' ) );
$posts_page_url = thilo_get_posts_page_url();
$playlists      = thilo_get_field_safe( 'playlists', [] );

if ( ! $portrait_url ) {
    $portrait_id  = get_theme_mod( 'thilo_portrait', '' );
    $portrait_url = $portrait_id ? wp_get_attachment_image_url( $portrait_id, 'large' ) : '';
}
?>

<!-- ═══════════════════════════════════════ 1. HERO ══════════════════════════ -->
<section class="site-hero site-hero--deep site-hero--front" id="home">
  <?php if ( $hero_bild ) : ?>
    <div class="site-hero-bg" aria-hidden="true" style="background-image:url('<?php echo esc_url( $hero_bild ); ?>');"></div>
  <?php endif; ?>
  <?php echo thilo_hero_pattern(); ?><div class="site-hero-grad"></div>

  <div class="site-hero-inner">
    <div class="hero-eyebrow reveal"><?php echo esc_html( $hero_eyebrow ); ?></div>
    <h1 class="hero-title reveal stagger-1">
      <?php echo esc_html( $hero_titel_1 ); ?><br>
      <?php echo esc_html( $hero_titel_2 ); ?><br>
      <em><?php echo esc_html( $hero_titel_3 ); ?></em>
    </h1>
    <p class="hero-subtitle reveal stagger-2"><?php echo esc_html( $hero_text ); ?></p>
    <div class="hero-actions reveal stagger-3">
      <a href="<?php echo esc_url( $hero_btn1_url ); ?>" class="btn-primary"><?php echo esc_html( $hero_btn1 ); ?></a>
      <a href="<?php echo esc_url( $hero_btn2_url ); ?>" class="btn-ghost"><?php echo esc_html( $hero_btn2 ); ?></a>
    </div>
  </div>
</section>

<!-- ══════════════════════════════════ 2. ÜBER MICH ═════════════════════════ -->
<section class="about" id="about-me">
  <div class="about-image-col">
    <?php if ( $portrait_url ) : ?>
      <img loading="lazy" src="<?php echo esc_url( $portrait_url ); ?>" alt="<?php echo esc_attr( $about_name ); ?>" class="about-portrait-img">
    <?php else : ?>
      <div class="about-portrait-placeholder">Portrait hochladen unter: Seiten → Startseite → Portrait-Foto</div>
    <?php endif; ?>
  </div>
  <div class="about-content">
    <div class="section-eyebrow reveal reveal-left">Über mich</div>
    <h2 class="about-name reveal stagger-1"><?php echo esc_html( $about_name ); ?></h2>
    <div class="about-roles"><?php echo esc_html( $about_rolle ); ?></div>
    <p class="about-bio reveal stagger-2"><?php echo esc_html( $about_bio ); ?></p>
    <div class="timeline">
      <div class="tl-item reveal-right stagger-1">
        <div><div class="tl-dot"></div></div>
        <div><div class="tl-year">2011</div><div class="tl-title">Der Verlust</div><div class="tl-desc">Stille Geburt meiner Tochter Katy-Lynn. Das Begreifen, das Brechen, der erste Schmerz.</div></div>
      </div>
      <div class="tl-item reveal-right stagger-2">
        <div><div class="tl-dot"></div></div>
        <div><div class="tl-year">2022</div><div class="tl-title">Der Wendepunkt</div><div class="tl-desc">Erste Schritte in Richtung Verarbeitung — Therapie, Schreiben, erste Ordnung.</div></div>
      </div>
      <div class="tl-item reveal-right stagger-3">
        <div><div class="tl-dot"></div></div>
        <div><div class="tl-year">2025</div><div class="tl-title">LifeTime Journey beginnt</div><div class="tl-desc">Aufbau des Projekts. Weitergabe von Erkenntnissen, Erfahrungen, Begleitung.</div></div>
      </div>
      <div class="tl-item reveal-right stagger-4">
        <div><div class="tl-dot"></div></div>
        <div><div class="tl-year">2026</div><div class="tl-title">Band 1 erscheint</div><div class="tl-desc">Die Fallstudie — alle Kapitel, alle Abschnitte, alle Erkenntnisse.</div></div>
      </div>
    </div>
    <a href="<?php echo esc_url( $about_page_url ); ?>" class="btn-ghost about-story-link">Meine Geschichte</a>
  </div>
</section>

<!-- ══════════════════════════════ 3. ÜBER DIESE SEITE ══════════════════════ -->
<div class="quote-divider reveal">
  <div class="quote-divider-inner">
    <blockquote class="quote-divider-text">„Am Grab dachte ich, mein Leben sei vorbei — dass Trauer und Verbitterung das Einzige wären, was bleibt. Ich habe einen Weg herausgefunden. Nicht weil der Schmerz verschwunden ist, sondern weil ich mich dabei nicht verloren habe."</blockquote>
    <cite class="quote-divider-cite">— Thilo Hospes, Sternenkindvater &amp; Autor</cite>
  </div>
</div>

<section class="site-info" id="about">
  <div class="site-info-inner">
    <div class="section-eyebrow">Über diese Seite</div>
    <div class="si-row1 reveal">
      <p class="si-row1-sub">Kein Pathos. Keine Floskeln. <span class="site-info-highlight">Nur das, was trägt.</span></p>
      <p class="si-row1-desc">Diese Seite ist kein Blog und keine Therapieplattform. Sie ist ein strukturierter Begleiter — für Menschen, die einen Verlust erlebt haben, für jene, die begleiten, und für alle, die verstehen wollen, was im Inneren passiert, wenn das Leben sich teilt.</p>
    </div>
    <div class="site-info-grid si-row2">
      <div class="si-block reveal stagger-1">
        <div class="si-num">01</div>
        <div class="si-cat">Was du hier findest</div>
        <h3 class="si-title">Inhalte, Formate &amp; Themen</h3>
        <p class="si-text">Psychotraumatologische Fallanalysen, Erfahrungsberichte, Theoriebeiträge und praxisnahe Erklärungen — als Artikel, YouTube-Playlists und strukturierte Fallstudie in Buchform.</p>
        <div class="si-tags"><span class="si-tag">Fallstudie</span><span class="si-tag">Artikel</span><span class="si-tag">YouTube</span><span class="si-tag">Trauermodelle</span></div>
      </div>
      <div class="si-block reveal stagger-2">
        <div class="si-num">02</div>
        <div class="si-cat">Für wen diese Seite ist</div>
        <h3 class="si-title">Betroffene, Begleitende &amp; Fachleute</h3>
        <p class="si-text">Pfad A für Betroffene — Menschen, die selbst in einem Trauerprozess sind. Pfad B für Begleitende — Partner, Freunde, Familie — die verstehen wollen, wie sie wirklich helfen können.</p>
        <div class="si-tags"><span class="si-tag">Pfad A · Betroffene</span><span class="si-tag">Pfad B · Begleitende</span></div>
      </div>
      <div class="si-block reveal stagger-3">
        <div class="si-num">03</div>
        <div class="si-cat">Warum diese Seite existiert</div>
        <h3 class="si-title">Persönliche Motivation</h3>
        <p class="si-text">2011 verlor ich meine Tochter Katy-Lynn durch eine stille Geburt. Diese Seite ist meine Antwort darauf. Nicht als Experte, der erklärt — sondern als jemand, der denselben Weg gegangen ist.</p>
        <div class="si-tags"><span class="si-tag">Stille Geburt 2011</span><span class="si-tag">Authentizität</span></div>
      </div>
      <div class="si-block reveal stagger-4">
        <div class="si-num">04</div>
        <div class="si-cat">In deinem Tempo</div>
        <h3 class="si-title">Kein Programm, kein Druck</h3>
        <p class="si-text">Du entscheidest, was du liest und wann. Die Inhalte warten — du gehst deinen Weg. Jeder Schritt zählt, auch wenn er klein ist.</p>
        <div class="si-tags"><span class="si-tag">Pfad A / B</span><span class="si-tag">Band 1</span></div>
      </div>
    </div>
    <div class="si-row3">
      <div class="quote-block reveal reveal-left">
        <blockquote>„Ich mach das für mein Sternenkind — für meine Tochter. Damit ihr Sein nicht in Vergessenheit gerät."</blockquote>
        <cite>— Thilo Hospes, Sternenkindvater &amp; Autor</cite>
      </div>
      <div class="si-row3-text reveal stagger-1">
        <p class="site-col-text">Diese Seite wächst mit jedem Band, jedem Artikel, jeder Erkenntnis. Sie ist kein abgeschlossenes Werk — sie ist ein Prozess. Genau wie Trauer selbst.</p>
        <p class="site-col-text">Was du hier findest, ist nicht perfekt formuliert. Es ist ehrlich formuliert. Der Unterschied ist entscheidend — für jene, die in einer Phase sind, wo Perfektion sich wie Hohn anfühlt.</p>
        <p class="site-col-text">Wenn du dich in diesen Inhalten wiedererkennst: Du bist richtig hier.</p>
      </div>
    </div>
  </div>
</section>

<!-- ════════════════════════════════ PFAD A / B ══════════════════════════════ -->
<section class="pfad-split" id="pfade">
  <div class="pfad-split-col pfad-a">
    <div class="pfad-split-inner">
      <div class="pfad-badge pfad-badge-a reveal">Pfad A — Betroffene</div>
      <h2 class="pfad-split-title reveal stagger-1"><?php echo nl2br( esc_html( thilo_get_field_safe( 'pfad_a_titel', 'Du erkennst dich in diesem Verlauf.' ) ) ); ?></h2>
      <p class="pfad-split-text reveal stagger-2"><?php echo esc_html( thilo_get_field_safe( 'pfad_a_text', 'Zunächst: Alle Inhalte haben Bestand. Niemand, der hier ist, sollte allein bleiben. Wenn du erkennst, dass du trauern darfst — in deinem eigenen Tempo, mit Pfad-eigener Gewichtung, in deiner Geschichte.' ) ); ?></p>
      <a href="<?php echo esc_url( $pfad_a_url ); ?>" class="btn-primary reveal stagger-3">Zum Pfad A</a>
    </div>
    <div class="pfad-split-orb" aria-hidden="true"></div>
  </div>
  <div class="pfad-split-col pfad-b">
    <div class="pfad-split-inner">
      <div class="pfad-badge pfad-badge-b reveal">Pfad B — Begleitende</div>
      <h2 class="pfad-split-title reveal stagger-1"><?php echo nl2br( esc_html( thilo_get_field_safe( 'pfad_b_titel', 'Du begleitest einen trauernden Menschen.' ) ) ); ?></h2>
      <p class="pfad-split-text reveal stagger-2"><?php echo esc_html( thilo_get_field_safe( 'pfad_b_text', 'Was du brauchst, um da zu sein — was hilft und was nicht. Wie du Unterstützung gibst, ohne dich selbst aufzugeben. Primär keine Bewertungen. Du brauchst keine Außenwirkung.' ) ); ?></p>
      <a href="<?php echo esc_url( $pfad_b_url ); ?>" class="btn-primary reveal stagger-3">Zum Pfad B</a>
    </div>
    <div class="pfad-split-orb" aria-hidden="true"></div>
  </div>
</section>

<!-- ══════════════════════════════ QUIZ-TEASER ═══════════════════════════════ -->
<section class="quiz-teaser">
  <div class="quiz-teaser-inner">
    <div class="quiz-teaser-text reveal">
      <div class="section-eyebrow">Geführte Orientierung</div>
      <h2 class="quiz-teaser-title">Nicht sicher, wo du anfangen sollst?</h2>
      <p class="quiz-teaser-desc">Beantworte drei kurze Fragen — du bekommst sofort die Artikel, die zu deiner Situation passen.</p>
    </div>
    <a href="<?php echo esc_url( thilo_get_leitpfad_selection_url() ); ?>" class="btn-primary reveal stagger-1">Fragen beantworten</a>
  </div>
</section>

<!-- ════════════════════════════ 4. THEMENBEREICHE ══════════════════════════ -->
<section class="themes" id="themes">
  <div class="themes-hd">
    <div>
      <div class="section-eyebrow reveal">Inhalte</div>
      <h2 class="section-title reveal stagger-1">Alle <em>Themenbereiche</em></h2>
    </div>
    <a href="<?php echo esc_url( $themes_url ); ?>" class="btn-ghost reveal stagger-2">Alle Kategorien</a>
  </div>
  <div class="themes-grid">
    <?php
    $cats = get_categories([
      'hide_empty' => false,
      'orderby'    => 'name',
      'number'     => 6,
      'exclude'    => thilo_get_default_category_id(),
    ]);
    $descriptions = [
      'Trauer'                     => 'Was Trauer im Körper auslöst, wie sie sich verändert und warum sie kein linearer Prozess ist.',
      'Sternenkind'                => 'Stille Geburt, Fehlgeburt, Regelungen und Erinnerungen. Texte, die benennen, was oft unausgesprochen bleibt.',
      'Pfad A'                     => 'Für Menschen, die selbst einen Verlust erlebt haben. Artikel, die dich dort abholen, wo du gerade stehst.',
      'Pfad B'                     => 'Für Menschen, die jemanden in der Trauer begleiten. Was hilft — und was nur gut gemeint ist.',
      'Fallstudie Band 1 - Teil 1' => 'Meine Geschichte. Ungefiltert, Kapitel für Kapitel. Von der stillen Geburt bis zum Weg zurück.',
      'Allgemein'                  => 'Übergreifende Themen rund um Trauma, Heilung und persönliches Wachstum nach schwerem Verlust.',
    ];
    if ( $cats ) :
      foreach ( $cats as $i => $cat ) :
        $desc = $descriptions[ $cat->name ] ?? $cat->description;
    ?>
    <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="theme-card reveal stagger-<?php echo ( $i % 3 ) + 1; ?>">
      <div class="theme-num"><?php echo str_pad( $i + 1, 2, '0', STR_PAD_LEFT ); ?></div>
      <div class="theme-cat">Kategorie</div>
      <h3 class="theme-title"><?php echo esc_html( $cat->name ); ?></h3>
      <?php if ( $desc ) : ?>
        <p class="theme-desc"><?php echo esc_html( $desc ); ?></p>
      <?php endif; ?>
      <span class="theme-link"><?php echo $cat->count > 0 ? esc_html( $cat->count . ' Artikel →' ) : 'Zur Kategorie →'; ?></span>
    </a>
    <?php endforeach; endif; ?>
  </div>
</section>

<!-- ════════════════════════════ 5. NEUESTE BEITRÄGE ════════════════════════ -->
<section class="posts" id="posts">
  <div class="posts-hd">
    <div>
      <div class="section-eyebrow reveal">Aktuell</div>
      <h2 class="section-title reveal stagger-1">Neueste <em>Beiträge</em></h2>
    </div>
    <a href="<?php echo esc_url( $posts_page_url ); ?>" class="btn-ghost reveal stagger-2">Alle Beiträge</a>
  </div>
  <div class="posts-grid">
    <?php
    $latest = new WP_Query([
      'post_type'      => 'post',
      'posts_per_page' => 3,
      'orderby'        => 'date',
      'order'          => 'DESC',
      'post_status'    => 'publish',
    ]);
    $pi = 0;
    if ( $latest->have_posts() ) :
      while ( $latest->have_posts() ) :
        $latest->the_post();
        $pi++;
        $cats     = get_the_category();
        $cat_name = $cats ? $cats[0]->name : 'Beitrag';
        $lesezeit = get_post_meta( get_the_ID(), '_lesezeit', true );
    ?>
    <a class="post-card reveal stagger-<?php echo $pi; ?>" href="<?php echo esc_url( get_permalink() ); ?>">
      <div class="post-cat"><?php echo esc_html( $cat_name ); ?></div>
      <h3 class="post-title"><?php echo esc_html( get_the_title() ); ?></h3>
      <?php if ( has_excerpt() ) : ?>
        <p class="post-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
      <?php endif; ?>
      <div class="post-date">
        <?php echo esc_html( get_the_date( 'd. F Y' ) ); ?>
        <?php if ( $lesezeit ) : ?> · <?php echo absint( $lesezeit ); ?> Min. Lesezeit<?php endif; ?>
      </div>
    </a>
    <?php endwhile; wp_reset_postdata(); else : ?>
      <p class="front-posts-empty">Noch keine Beiträge veröffentlicht.</p>
    <?php endif; ?>
  </div>
</section>

<!-- ════════════════════════════════ 6. YOUTUBE ═════════════════════════════ -->
<section class="youtube" id="youtube">
  <div class="section-eyebrow">YouTube-Playlists</div>
  <h2 class="section-title">Inhalte zum <em>Ansehen</em></h2>
  <div class="yt-grid">
  <?php if ( ! empty( $playlists ) && is_array( $playlists ) ) : ?>
    <?php foreach ( $playlists as $i => $pl ) : ?>
      <a href="<?php echo esc_url( $pl['url'] ?? $yt_url ); ?>" target="_blank" rel="noopener" class="yt-item reveal stagger-<?php echo ( $i % 5 ) + 1; ?>">
        <div class="yt-play"><svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg></div>
        <div>
          <?php if ( ! empty( $pl['label'] ) ) : ?><div class="yt-label"><?php echo esc_html( $pl['label'] ); ?></div><?php endif; ?>
          <div class="yt-title"><?php echo esc_html( $pl['titel'] ?? '' ); ?></div>
          <?php if ( ! empty( $pl['count'] ) ) : ?><div class="yt-count"><?php echo esc_html( $pl['count'] ); ?></div><?php endif; ?>
        </div>
      </a>
    <?php endforeach; ?>
  <?php else :
    $fallback = [
      [ 'label' => 'Playlist · Einleitung', 'titel' => 'LifeTime Journey — Einleitung', 'count' => '1 Video · Warum ich diesen Kanal gestartet habe' ],
      [ 'label' => 'Playlist · Kapitel 1', 'titel' => 'LifeTime Journey — Mein Sternenkind: Kapitel 1', 'count' => '9 Videos · Meine Geschichte' ],
      [ 'label' => 'Playlist · Bonus-Serie', 'titel' => 'Bonus-Serie: Trauer verstehen!', 'count' => '12 Videos' ],
      [ 'label' => 'Playlist · Bonus-Serie', 'titel' => 'Bonus-Serie: Trauer in der Gesellschaft!', 'count' => '5 Videos' ],
      [ 'label' => 'Playlist · Themen-Video', 'titel' => 'Was ist ein Sternenkind?', 'count' => '1 Video' ],
    ];
    foreach ( $fallback as $i => $pl ) : ?>
      <a href="<?php echo esc_url( $yt_url ); ?>" target="_blank" rel="noopener" class="yt-item reveal stagger-<?php echo $i + 1; ?>">
        <div class="yt-play"><svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg></div>
        <div>
          <div class="yt-label"><?php echo esc_html( $pl['label'] ); ?></div>
          <div class="yt-title"><?php echo esc_html( $pl['titel'] ); ?></div>
          <div class="yt-count"><?php echo esc_html( $pl['count'] ); ?></div>
        </div>
      </a>
    <?php endforeach; endif; ?>
  </div>
</section>

<!-- ════════════════════════════ 7. ABSCHLUSS-ZITAT ═════════════════════════ -->
<section class="closing-section">
  <div class="closing-section-inner">
    <div class="reveal closing-section-kicker">
      <span class="closing-section-line"></span>
      <span class="closing-section-label">LifeTime Journey</span>
      <span class="closing-section-line"></span>
    </div>
    <p class="reveal stagger-1 closing-section-quote">„Schwere Dinge tragen —<br>und trotzdem <em>wachsen.</em>"</p>
    <p class="reveal stagger-2 closing-section-cite">— Thilo Hospes, Sternenkindvater &amp; Autor</p>
  </div>
</section>

<?php get_footer(); ?>
