<?php
/**
 * Theme setup, assets and frontend enqueue logic.
 */

// ─── Theme Setup ──────────────────────────────────────────────────────────────
add_action( 'after_setup_theme', function() {
    load_theme_textdomain( THILO_THEME_TEXTDOMAIN, get_template_directory() . '/languages' );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 80,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    register_nav_menus([
        'primary' => __( 'Hauptnavigation', THILO_THEME_TEXTDOMAIN ),
        'mobile'  => __( 'Mobile Navigation', THILO_THEME_TEXTDOMAIN ),
    ]);
});

// ─── Enqueue Styles & Scripts ─────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', function() {
    $theme_dir = get_template_directory();

    /**
     * Hilfsfunktion: Gibt filemtime der Datei zurück, falls vorhanden —
     * sonst THILO_THEME_VERSION als Fallback. So werden Browser-Caches
     * automatisch bei jeder Dateiänderung gebrochen, ohne manuelle Versionsbumps.
     */
    $ver = static function( string $rel_path ): string {
        $abs = get_template_directory() . $rel_path;
        return file_exists( $abs ) ? (string) filemtime( $abs ) : THILO_THEME_VERSION;
    };

    // Google Fonts
    wp_enqueue_style(
        'thilo-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@300;400;500&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'thilo-style',
        get_stylesheet_uri(),
        [ 'thilo-fonts' ],
        $ver( '/style.css' )
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }

    if ( is_post_type_archive( 'leitpfad' ) || is_page_template( 'page-orientierung.php' ) ) {
        wp_enqueue_style(
            'thilo-quiz',
            get_template_directory_uri() . '/assets/css/quiz.css',
            [ 'thilo-style' ],
            $ver( '/assets/css/quiz.css' )
        );

        wp_enqueue_script(
            'thilo-quiz',
            get_template_directory_uri() . '/assets/js/quiz.js',
            [],
            $ver( '/assets/js/quiz.js' ),
            true
        );
        wp_script_add_data( 'thilo-quiz', 'strategy', 'defer' );
    }

    // Navigation JS
    wp_enqueue_script(
        'thilo-navigation',
        get_template_directory_uri() . '/assets/js/navigation.js',
        [],
        $ver( '/assets/js/navigation.js' ),
        true
    );
    wp_script_add_data( 'thilo-navigation', 'strategy', 'defer' );

    // Main JS — defer so it doesn't block rendering
    wp_enqueue_script(
        'thilo-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        $ver( '/assets/js/main.js' ),
        true
    );
    wp_script_add_data( 'thilo-main', 'strategy', 'defer' );

    // Cookie-Consent + Analytics
    $cookie_banner_enabled = ! get_option( 'thilo_cookie_notice_disabled', false );
    $ga_id                 = sanitize_text_field( get_theme_mod( 'thilo_ga_id', '' ) );

    if ( $cookie_banner_enabled || $ga_id ) {
        wp_enqueue_script(
            'thilo-consent',
            get_template_directory_uri() . '/assets/js/consent.js',
            [],
            $ver( '/assets/js/consent.js' ),
            true
        );
        wp_script_add_data( 'thilo-consent', 'strategy', 'defer' );
        wp_add_inline_script(
            'thilo-consent',
            'window.thiloConsentConfig = ' . wp_json_encode(
                [
                    'bannerEnabled' => $cookie_banner_enabled,
                    'gaId'          => $ga_id,
                ],
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            ) . ';',
            'before'
        );
    }
});
