<?php
/**
 * Leitpfad FAQ generation, schema and markup.
 */

/**
 * Check whether a Leitpfad heading is a sources/references section.
 */
function thilo_is_leitpfad_sources_heading( $heading ) {
    $heading = thilo_normalize_leitpfad_faq_text( $heading );

    if ( '' === $heading ) {
        return false;
    }

    return (bool) preg_match( '/(quellen|literatur|weiterf(?:ue|ü)hrende|studien|nachweise|referenzen|verwendete quellen)/iu', $heading );
}

/**
 * Normalize text for automatically generated Leitpfad FAQ items.
 */
function thilo_normalize_leitpfad_faq_text( $text ) {
    $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    $text = preg_replace( '/\s+/u', ' ', $text );

    return trim( (string) $text );
}

/**
 * Build a short but complete FAQ excerpt from plain text.
 */
function thilo_build_leitpfad_faq_excerpt( $text, $max_sentences = 2, $max_words = 52 ) {
    $text = trim( (string) $text );

    if ( '' === $text ) {
        return '';
    }

    $sentences = preg_split( '/(?<=[.!?])\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

    if ( ! is_array( $sentences ) ) {
        $sentences = array( $text );
    }

    $selected = array();
    $word_sum = 0;

    foreach ( $sentences as $sentence ) {
        $sentence = trim( (string) $sentence );

        if ( '' === $sentence ) {
            continue;
        }

        $words = preg_split( '/\s+/u', $sentence, -1, PREG_SPLIT_NO_EMPTY );
        $count = is_array( $words ) ? count( $words ) : 0;

        if ( 0 === $count ) {
            continue;
        }

        if ( ! empty( $selected ) && ( count( $selected ) >= $max_sentences || ( $word_sum + $count ) > $max_words ) ) {
            break;
        }

        $selected[] = $sentence;
        $word_sum  += $count;

        if ( count( $selected ) >= $max_sentences ) {
            break;
        }
    }

    if ( empty( $selected ) ) {
        $selected[] = trim( (string) $sentences[0] );
    }

    $excerpt = trim( implode( ' ', $selected ) );

    if ( '' === $excerpt ) {
        $excerpt = $text;
    }

    if ( ! preg_match( '/[.!?]$/u', $excerpt ) ) {
        $excerpt .= '.';
    }

    return $excerpt;
}

/**
 * Decide whether a heading should be skipped in the generated FAQ.
 */
function thilo_should_skip_leitpfad_faq_heading( $heading ) {
    $heading = thilo_normalize_leitpfad_faq_text( $heading );

    if ( '' === $heading ) {
        return true;
    }

    $heading_lower = function_exists( 'mb_strtolower' )
        ? mb_strtolower( $heading, 'UTF-8' )
        : strtolower( $heading );

    $skip_tokens = array(
        'quellen',
        'weiterführende literatur',
        'weiterfuehrende literatur',
        'literatur',
        'faq',
        'häufige fragen',
        'haeufige fragen',
        'einleitung',
        'fazit',
        'schluss',
        'zusammenfassung',
        'überblick',
        'ueberblick',
        'vorwort',
    );

    foreach ( $skip_tokens as $token ) {
        if ( false !== strpos( $heading_lower, $token ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Convert article headings into readable FAQ questions.
 *
 * Strategy:
 * 1. Heading already ends with "?" → use directly.
 * 2. Heading contains "—", "–", ":" → check if the part after it starts with
 *    a question word and use that part if so.
 * 3. Full heading starts with a question word → append "?".
 * 4. Context-aware fallback based on topic clues.
 */
function thilo_build_leitpfad_faq_question( $heading ) {
    $heading = thilo_normalize_leitpfad_faq_text( $heading );
    $heading = trim( $heading, " \t\n\r\0\x0B-–—:;,.!?" );

    if ( '' === $heading ) {
        return '';
    }

    // Already a question
    if ( '?' === substr( rtrim( $heading ), -1 ) ) {
        return $heading;
    }

    $mb = function_exists( 'mb_strtolower' );

    $heading_lower = $mb ? mb_strtolower( $heading, 'UTF-8' ) : strtolower( $heading );

    $question_words = array(
        'was ', 'wie ', 'warum ', 'wieso ', 'weshalb ', 'wann ', 'wer ',
        'wo ', 'woran ', 'wofür ', 'wofuer ', 'welche ', 'welcher ',
        'welches ', 'kann ', 'darf ', 'soll ', 'sollte ', 'hilft ',
        'macht ', 'ist ', 'sind ', 'gibt ', 'brauche ', 'braucht ',
        'lohnt ', 'muss ', 'müssen ', 'muessen ', 'typische ',
    );

    // Split on em-dash, en-dash or colon — use the part after if it's a question
    if ( preg_match( '/[—–:]\s*(.+)$/u', $heading, $m ) ) {
        $after       = trim( $m[1] );
        $after_lower = $mb ? mb_strtolower( $after, 'UTF-8' ) : strtolower( $after );

        foreach ( $question_words as $qw ) {
            if ( 0 === strpos( $after_lower, $qw ) ) {
                return rtrim( $after, '?' ) . '?';
            }
        }
    }

    // Full heading starts with a question word
    foreach ( $question_words as $qw ) {
        if ( 0 === strpos( $heading_lower, $qw ) ) {
            return rtrim( $heading, '?' ) . '?';
        }
    }

    // "wenn …" → rephrase
    if ( 0 === strpos( $heading_lower, 'wenn ' ) ) {
        $rest = $mb ? mb_strtolower( substr( $heading, 5 ), 'UTF-8' ) : strtolower( substr( $heading, 5 ) );
        return 'Was ist wichtig, wenn ' . $rest . '?';
    }

    // Context-aware fallbacks
    $partner_clues = array( 'partner', 'beziehung', 'paar', 'familie' );
    $body_clues    = array( 'körper', 'koerper', 'schlaf', 'erschöpf', 'müdigkeit', 'hormon' );
    $help_clues    = array( 'therapie', 'hilfe', 'unterstützung', 'begleitung', 'selbsthilfe', 'ritual' );
    $social_clues  = array( 'umfeld', 'freunde', 'arbeit', 'kollegen', 'gesellschaft' );

    foreach ( $partner_clues as $c ) {
        if ( false !== strpos( $heading_lower, $c ) ) {
            return 'Wie beeinflusst ' . $heading . ' den Trauerprozess?';
        }
    }
    foreach ( $body_clues as $c ) {
        if ( false !== strpos( $heading_lower, $c ) ) {
            return 'Welche Rolle spielt ' . $heading . ' in der Trauer?';
        }
    }
    foreach ( $help_clues as $c ) {
        if ( false !== strpos( $heading_lower, $c ) ) {
            return 'Wann hilft ' . $heading . '?';
        }
    }
    foreach ( $social_clues as $c ) {
        if ( false !== strpos( $heading_lower, $c ) ) {
            return 'Wie reagiert ' . $heading . ' auf Trauer?';
        }
    }

    return 'Was steckt hinter ' . $heading . '?';
}

/**
 * Build a compact answer excerpt from HTML fragments.
 */
function thilo_build_leitpfad_faq_answer( $fragments, $max_segments = 2, $max_words = 58 ) {
    if ( empty( $fragments ) || ! is_array( $fragments ) ) {
        return '';
    }

    $segments = array();

    foreach ( $fragments as $fragment ) {
        if ( ! is_string( $fragment ) || '' === trim( $fragment ) ) {
            continue;
        }

        if ( preg_match( '/^\s*<h[1-6]\b/i', $fragment ) ) {
            continue;
        }

        $text = thilo_normalize_leitpfad_faq_text( $fragment );

        if ( '' === $text ) {
            continue;
        }

        $segments[] = $text;

        if ( count( $segments ) >= $max_segments ) {
            break;
        }
    }

    if ( empty( $segments ) ) {
        $text = thilo_normalize_leitpfad_faq_text( implode( '', $fragments ) );
        return thilo_build_leitpfad_faq_excerpt( $text, $max_segments, $max_words );
    }

    return thilo_build_leitpfad_faq_excerpt( implode( ' ', $segments ), $max_segments, $max_words );
}

/**
 * Extract h3 based sub-sections from a Leitpfad h2 section.
 */
function thilo_get_leitpfad_faq_subsections( $content_fragments ) {
    if ( empty( $content_fragments ) || ! is_array( $content_fragments ) ) {
        return array();
    }

    $subsections = array();
    $current     = null;

    foreach ( $content_fragments as $fragment ) {
        if ( ! is_string( $fragment ) || '' === trim( $fragment ) ) {
            continue;
        }

        if ( preg_match( '/^\s*<h3[^>]*>(.*?)<\/h3>\s*$/isu', $fragment, $matches ) ) {
            if ( null !== $current ) {
                $subsections[] = $current;
            }

            $current = array(
                'heading' => thilo_normalize_leitpfad_faq_text( $matches[1] ),
                'content' => array(),
            );

            continue;
        }

        if ( null !== $current ) {
            $current['content'][] = $fragment;
        }
    }

    if ( null !== $current ) {
        $subsections[] = $current;
    }

    return $subsections;
}

/**
 * Generate FAQ items for Leitpfad articles from the actual article content.
 */
function thilo_get_leitpfad_faq_items( $post_id, $limit = 10 ) {
    static $cache = array();

    $post_id = absint( $post_id );
    $limit   = max( 1, absint( $limit ) );
    $key     = $post_id . ':' . $limit;

    if ( isset( $cache[ $key ] ) ) {
        return $cache[ $key ];
    }

    if ( ! $post_id || ! class_exists( 'DOMDocument' ) ) {
        $cache[ $key ] = array();
        return $cache[ $key ];
    }

    $raw_content = (string) get_post_field( 'post_content', $post_id );

    if ( '' === trim( $raw_content ) ) {
        $cache[ $key ] = array();
        return $cache[ $key ];
    }

    $content = do_shortcode( $raw_content );

    $previous_state = libxml_use_internal_errors( true );

    $dom    = new DOMDocument( '1.0', 'UTF-8' );
    $html   = '<?xml encoding="utf-8" ?><div id="ltj-faq-root">' . $content . '</div>';
    $loaded = $dom->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

    if ( ! $loaded ) {
        libxml_clear_errors();
        libxml_use_internal_errors( $previous_state );
        $cache[ $key ] = array();
        return $cache[ $key ];
    }

    $root = $dom->getElementById( 'ltj-faq-root' );

    if ( ! $root ) {
        libxml_clear_errors();
        libxml_use_internal_errors( $previous_state );
        $cache[ $key ] = array();
        return $cache[ $key ];
    }

    $intro_nodes = array();
    $sections    = array();
    $current     = null;

    foreach ( iterator_to_array( $root->childNodes ) as $node ) {
        $node_html = $dom->saveHTML( $node );

        if ( false === $node_html ) {
            continue;
        }

        $is_h2 = XML_ELEMENT_NODE === $node->nodeType && 'h2' === strtolower( $node->nodeName );

        if ( $is_h2 ) {
            if ( null !== $current ) {
                $sections[] = $current;
            }

            $current = array(
                'heading' => thilo_normalize_leitpfad_faq_text( $node->textContent ),
                'content' => array(),
            );

            continue;
        }

        if ( null === $current ) {
            $intro_nodes[] = $node_html;
        } else {
            $current['content'][] = $node_html;
        }
    }

    if ( null !== $current ) {
        $sections[] = $current;
    }

    libxml_clear_errors();
    libxml_use_internal_errors( $previous_state );

    $intro_answer = thilo_build_leitpfad_faq_answer( $intro_nodes, 2, 64 );
    $post_title   = thilo_normalize_leitpfad_faq_text( get_the_title( $post_id ) );

    $fallbacks = array();

    if ( '' !== $intro_answer ) {
        $fallbacks[] = array(
            'question' => 'Worum geht es in diesem Leitpfad-Artikel?',
            'answer'   => $intro_answer,
        );

        if ( '' !== $post_title ) {
            $fallbacks[] = array(
                'question' => 'Was steht in ' . $post_title . '?',
                'answer'   => $intro_answer,
            );
        }
    }

    $items          = array();
    $seen_questions = array();

    $add_item = static function( $question, $answer ) use ( &$items, &$seen_questions, $limit ) {
        $question = thilo_normalize_leitpfad_faq_text( $question );
        $answer   = thilo_normalize_leitpfad_faq_text( $answer );

        if ( '' === $question || '' === $answer ) {
            return;
        }

        $question_key = function_exists( 'mb_strtolower' )
            ? mb_strtolower( $question, 'UTF-8' )
            : strtolower( $question );

        if ( isset( $seen_questions[ $question_key ] ) || count( $items ) >= $limit ) {
            return;
        }

        $seen_questions[ $question_key ] = true;
        $items[] = array(
            'question' => $question,
            'answer'   => $answer,
        );
    };

    foreach ( $fallbacks as $fallback ) {
        $add_item( $fallback['question'], $fallback['answer'] );
    }

    foreach ( $sections as $section ) {
        if ( thilo_should_skip_leitpfad_faq_heading( $section['heading'] ) ) {
            continue;
        }

        $question = thilo_build_leitpfad_faq_question( $section['heading'] );
        $answer   = thilo_build_leitpfad_faq_answer( $section['content'] );

        $add_item( $question, $answer );

        foreach ( thilo_get_leitpfad_faq_subsections( $section['content'] ) as $subsection ) {
            if ( thilo_should_skip_leitpfad_faq_heading( $subsection['heading'] ) ) {
                continue;
            }

            $sub_question = thilo_build_leitpfad_faq_question( $subsection['heading'] );
            $sub_answer   = thilo_build_leitpfad_faq_answer( $subsection['content'] );

            $add_item( $sub_question, $sub_answer );
        }
    }

    if ( count( $items ) < $limit && ! empty( $sections ) ) {
        $last_section = end( $sections );

        if ( is_array( $last_section ) && ! thilo_should_skip_leitpfad_faq_heading( $last_section['heading'] ) ) {
            $add_item( 'Was bleibt aus diesem Artikel besonders wichtig?', thilo_build_leitpfad_faq_answer( $last_section['content'], 2, 60 ) );
        }
    }

    $cache[ $key ] = array_slice( $items, 0, $limit );

    return $cache[ $key ];
}

/**
 * Render the FAQ section for normal posts.
 */
function thilo_render_post_faq_section( $post_id ) {
    $faq_items = thilo_get_leitpfad_faq_items( $post_id );

    if ( empty( $faq_items ) ) {
        return;
    }
    ?>
    <section class="post-faq-wrap" aria-labelledby="post-faq-heading">
        <div class="post-faq-inner">
            <div class="post-faq-kicker">FAQ</div>
            <h2 class="post-faq-title" id="post-faq-heading">Häufige Fragen zum Artikel</h2>
            <div class="post-faq-list">
                <?php foreach ( $faq_items as $index => $faq_item ) : ?>
                    <details class="post-faq-item"<?php echo 0 === $index ? ' open' : ''; ?>>
                        <summary class="post-faq-question">
                            <span><?php echo esc_html( $faq_item['question'] ); ?></span>
                            <span class="post-faq-icon" aria-hidden="true"></span>
                        </summary>
                        <div class="post-faq-answer">
                            <p><?php echo esc_html( $faq_item['answer'] ); ?></p>
                        </div>
                    </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
}

/**
 * Output FAQPage structured data for Leitpfad articles AND regular posts.
 */
add_action( 'wp_head', function() {
    $faq_items = array();

    if ( is_singular( array( 'post', 'leitpfad' ) ) ) {
        $faq_items = thilo_get_leitpfad_faq_items( get_queried_object_id(), 10 );
    }

    if ( empty( $faq_items ) ) {
        return;
    }

    $schema = array(
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => array(),
    );

    foreach ( $faq_items as $item ) {
        $schema['mainEntity'][] = array(
            '@type'          => 'Question',
            'name'           => $item['question'],
            'acceptedAnswer' => array(
                '@type' => 'Answer',
                'text'  => $item['answer'],
            ),
        );
    }

    echo "\n" . '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 30 );


/**
 * Build the Leitpfad FAQ section markup.
 */
function thilo_get_leitpfad_faq_section_html( $post_id ) {
    $faq_items = thilo_get_leitpfad_faq_items( $post_id, 10 );

    if ( empty( $faq_items ) ) {
        return '';
    }

    ob_start();
    ?>
    <section class="leitpfad-faq-wrap" aria-labelledby="leitpfad-faq-heading">
        <div class="leitpfad-faq-panel">
            <div class="leitpfad-faq-kicker">FAQ</div>
            <h2 class="leitpfad-faq-title" id="leitpfad-faq-heading">Häufige Fragen zum Artikel</h2>
            <div class="leitpfad-faq-list">
                <?php foreach ( $faq_items as $index => $faq_item ) : ?>
                    <details class="leitpfad-faq-item"<?php echo 0 === $index ? ' open' : ''; ?>>
                        <summary class="leitpfad-faq-question">
                            <span><?php echo esc_html( $faq_item['question'] ); ?></span>
                            <span class="leitpfad-faq-icon" aria-hidden="true"></span>
                        </summary>
                        <div class="leitpfad-faq-answer">
                            <p><?php echo esc_html( $faq_item['answer'] ); ?></p>
                        </div>
                    </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php

    return (string) ob_get_clean();
}

/**
 * Render the Leitpfad FAQ section markup.
 */
function thilo_render_leitpfad_faq_section( $post_id ) {
    echo thilo_get_leitpfad_faq_section_html( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

}
