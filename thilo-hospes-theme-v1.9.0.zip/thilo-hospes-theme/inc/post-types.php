<?php
/**
 * Post types, taxonomies and init cleanup.
 */

// ─── Init: Bloat entfernen + Custom Post Types + Taxonomien registrieren ───────
// Core block styles bleiben aktiv, damit Gutenberg/Global Styles stabil bleiben.
add_action( 'init', function() {

    // Unbenötigte WordPress-Ausgaben im <head> entfernen
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
    remove_action( 'wp_head', 'wp_oembed_add_host_js' );
    remove_action( 'wp_head', 'rsd_link' );
    remove_action( 'wp_head', 'wlwmanifest_link' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );
    remove_action( 'wp_head', 'wp_generator' );

    // ── Custom Post Type: Leitpfade ───────────────────────────────────────────
    register_post_type( 'leitpfad', [
        'labels' => [
            'name'               => __( 'Leitpfade', THILO_THEME_TEXTDOMAIN ),
            'singular_name'      => __( 'Leitpfad', THILO_THEME_TEXTDOMAIN ),
            'add_new'            => __( 'Neu', THILO_THEME_TEXTDOMAIN ),
            'add_new_item'       => __( 'Neuen Leitpfad erstellen', THILO_THEME_TEXTDOMAIN ),
            'edit_item'          => __( 'Leitpfad bearbeiten', THILO_THEME_TEXTDOMAIN ),
            'new_item'           => __( 'Neuer Leitpfad', THILO_THEME_TEXTDOMAIN ),
            'view_item'          => __( 'Leitpfad ansehen', THILO_THEME_TEXTDOMAIN ),
            'search_items'       => __( 'Leitpfade suchen', THILO_THEME_TEXTDOMAIN ),
            'not_found'          => __( 'Keine Leitpfade gefunden', THILO_THEME_TEXTDOMAIN ),
            'not_found_in_trash' => __( 'Keine Leitpfade im Papierkorb', THILO_THEME_TEXTDOMAIN ),
            'menu_name'          => __( 'Leitpfade', THILO_THEME_TEXTDOMAIN ),
        ],
        'public'              => true,
        'has_archive'         => true,
        'rewrite'             => [ 'slug' => 'leitpfade' ],
        'supports'            => [ 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes' ],
        'menu_icon'           => 'dashicons-book-alt',
        'show_in_rest'        => true,
    ]);

    // Taxonomie: Phase
    register_taxonomy( 'phase', 'leitpfad', [
        'labels' => [
            'name'          => __( 'Phasen', THILO_THEME_TEXTDOMAIN ),
            'singular_name' => __( 'Phase', THILO_THEME_TEXTDOMAIN ),
            'search_items'  => __( 'Phasen suchen', THILO_THEME_TEXTDOMAIN ),
            'all_items'     => __( 'Alle Phasen', THILO_THEME_TEXTDOMAIN ),
            'edit_item'     => __( 'Phase bearbeiten', THILO_THEME_TEXTDOMAIN ),
            'add_new_item'  => __( 'Neue Phase', THILO_THEME_TEXTDOMAIN ),
        ],
        'hierarchical'      => true,
        'public'            => true,
        'rewrite'           => [ 'slug' => 'phase' ],
        'show_in_rest'      => true,
    ]);

    // Taxonomie: Pfad (A oder B)
    register_taxonomy( 'pfad', 'leitpfad', [
        'labels' => [
            'name'          => __( 'Pfade', THILO_THEME_TEXTDOMAIN ),
            'singular_name' => __( 'Pfad', THILO_THEME_TEXTDOMAIN ),
            'all_items'     => __( 'Alle Pfade', THILO_THEME_TEXTDOMAIN ),
            'add_new_item'  => __( 'Neuen Pfad erstellen', THILO_THEME_TEXTDOMAIN ),
        ],
        'hierarchical'      => true,
        'public'            => true,
        'rewrite'           => [ 'slug' => 'pfad' ],
        'show_in_rest'      => true,
    ]);

    // ── Custom Post Type: Bücher ──────────────────────────────────────────────
    register_post_type( 'buch', [
        'labels' => [
            'name'               => __( 'Bücher', THILO_THEME_TEXTDOMAIN ),
            'singular_name'      => __( 'Buch', THILO_THEME_TEXTDOMAIN ),
            'add_new'            => __( 'Neu', THILO_THEME_TEXTDOMAIN ),
            'add_new_item'       => __( 'Neues Buch erstellen', THILO_THEME_TEXTDOMAIN ),
            'edit_item'          => __( 'Buch bearbeiten', THILO_THEME_TEXTDOMAIN ),
            'view_item'          => __( 'Buch ansehen', THILO_THEME_TEXTDOMAIN ),
            'menu_name'          => __( 'Bücher', THILO_THEME_TEXTDOMAIN ),
        ],
        'public'              => true,
        'has_archive'         => false,
        'rewrite'             => [ 'slug' => 'buecher' ],
        'supports'            => [ 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes' ],
        'menu_icon'           => 'dashicons-book',
        'show_in_rest'        => true,
        'menu_position'       => 5,
    ]);
});
