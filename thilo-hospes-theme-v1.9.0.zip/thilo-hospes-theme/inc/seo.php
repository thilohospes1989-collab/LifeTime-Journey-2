<?php
/**
 * SEO metadata and cookie banner output.
 */

// ─── Open Graph / SEO Meta Tags ────────────────────────────────────────────────
add_action( 'wp_head', function() {
    global $post;

    $site_name  = get_bloginfo('name');
    $site_url   = home_url('/');
    $logo_url   = '';
    if ( has_custom_logo() ) {
        $logo_id  = get_theme_mod('custom_logo');
        $logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
    }

    // Defaults
    $title       = get_bloginfo('name') . ' — ' . get_bloginfo('description');
    $description = 'Psychologie, Trauer und Traumatherapie — aufgeschrieben von jemandem, der diesen Weg selbst gegangen ist.';
    $url         = home_url('/');
    $image       = $logo_url;
    $type        = 'website';

    if ( thilo_is_leitpfad_archive_page() ) {
        $title       = 'Leitpfad-Archiv — ' . $site_name;
        $description = 'Alle veröffentlichten Leitpfad-Artikel in einer ruhigen Übersicht. Direkter Zugriff auf alle Texte für Betroffene und Begleitende.';
        $url         = thilo_get_leitpfad_archive_url();
        $type        = 'website';
    } elseif ( is_singular() && isset($post) ) {
        $title       = get_the_title($post) . ' — ' . $site_name;
        $description = has_excerpt($post) ? get_the_excerpt($post) : wp_trim_words(get_the_content(), 30);
        $url         = get_permalink($post);
        $type        = 'article';

        // Post thumbnail
        if ( has_post_thumbnail($post) ) {
            $image = get_the_post_thumbnail_url($post, 'large');
        }
        // Buch cover
        if ( get_post_type($post) === 'buch' ) {
            $cover = get_post_meta($post->ID, '_cover_url', true);
            if ( $cover ) $image = $cover;
        }
        // Portrait for about
        if ( get_post_type($post) === 'page' ) {
            $portrait_id = get_theme_mod('thilo_portrait', '');
            if ( $portrait_id ) $image = wp_get_attachment_image_url($portrait_id, 'large');
        }
    }

    $description = esc_attr( wp_strip_all_tags($description) );
    $title       = esc_attr( $title );
    $image       = esc_url( $image );
    $url         = esc_url( $url );
    ?>
<!-- SEO & Open Graph -->
<meta name="description" content="<?php echo $description; ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?php echo $url; ?>">

<!-- Open Graph -->
<meta property="og:type" content="<?php echo esc_attr( $type ); ?>">
<meta property="og:title" content="<?php echo $title; ?>">
<meta property="og:description" content="<?php echo $description; ?>">
<meta property="og:url" content="<?php echo $url; ?>">
<meta property="og:site_name" content="<?php echo esc_attr($site_name); ?>">
<?php if ( $image ) : ?>
<meta property="og:image" content="<?php echo $image; ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<?php endif; ?>

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $title; ?>">
<meta name="twitter:description" content="<?php echo $description; ?>">
<?php if ( $image ) : ?>
<meta name="twitter:image" content="<?php echo $image; ?>">
<?php endif; ?>

<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "<?php echo esc_js( $type === 'article' ? 'Article' : 'WebSite' ); ?>",
  "name": "<?php echo esc_js($title); ?>",
  "url": "<?php echo esc_js($url); ?>",
  "description": "<?php echo esc_js($description); ?>",
  "author": {
    "@type": "Person",
    "name": "Thilo Hospes",
    "url": "<?php echo esc_js(home_url('/')); ?>"
  }
  <?php if ( $image ) echo ', "image": "' . esc_js($image) . '"'; ?>
}
</script>
<?php
}, 1 );

// ─── Cookie Banner (DSGVO) ─────────────────────────────────────────────────────
function thilo_render_cookie_banner() {
    if ( get_option( 'thilo_cookie_notice_disabled', false ) ) {
        return;
    }

    $ga_id = sanitize_text_field( get_theme_mod( 'thilo_ga_id', '' ) );
    ?>
<div class="cookie-banner" id="cookieBanner" role="dialog" aria-label="Cookie-Hinweis" aria-live="polite">
  <p class="cookie-banner-text">
    Diese Website verwendet technisch notwendige Cookies.
    <?php if ( $ga_id ) : ?>
    Mit Klick auf „Akzeptieren" stimmst du zusätzlich der Nutzung von Google Analytics zur anonymisierten Auswertung des Besucherverhaltens zu.
    <?php endif; ?>
    Weitere Infos in der <a href="<?php echo esc_url( thilo_get_legal_page_url( 'datenschutz' ) ); ?>">Datenschutzerklärung</a>.
  </p>
  <div class="cookie-banner-actions">
    <button type="button" class="cookie-decline" id="cookieDecline">Nur notwendige</button>
    <button type="button" class="cookie-accept" id="cookieAccept">Akzeptieren</button>
  </div>
</div>
<?php
}
add_action( 'wp_footer', 'thilo_render_cookie_banner', 20 );
