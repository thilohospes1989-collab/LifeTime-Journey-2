<?php
/**
 * Meta boxes, admin fields and save handlers.
 */

// ─── Custom Meta Fields: Leitpfad, Buch, Kauf-URL ─────────────────────────────
add_action( 'add_meta_boxes', function() {
    add_meta_box(
        'leitpfad_meta',
        'Leitpfad Details',
        'thilo_leitpfad_meta_box',
        'leitpfad',
        'side',
        'high'
    );
    add_meta_box(
        'buch_meta',
        'Buch Details',
        'thilo_buch_meta_box',
        'buch',
        'side',
        'high'
    );
    add_meta_box( 'buch_kauf_url', 'Kauf-Link', function( $post ) {
        wp_nonce_field( 'thilo_kauf_url', 'thilo_kauf_nonce' );
        $url = get_post_meta( $post->ID, '_kauf_url', true );
        echo '<p><label><strong>URL (Amazon, eigener Shop etc.)</strong></label><br>';
        echo '<input type="url" name="kauf_url" value="' . esc_attr( $url ) . '" class="widefat thilo-admin-field" placeholder="https://"></p>';
    }, 'buch', 'side' );
});

function thilo_leitpfad_meta_box( $post ) {
    wp_nonce_field( 'thilo_leitpfad_meta', 'thilo_leitpfad_nonce' );
    $pfad_typ    = get_post_meta( $post->ID, '_pfad_typ', true );
    $focus_kw    = get_post_meta( $post->ID, '_focus_keyword', true );
    $lesezeit    = get_post_meta( $post->ID, '_lesezeit', true );
    ?>
    <p>
      <label><strong>Pfad-Typ</strong></label><br>
      <select name="pfad_typ" class="widefat thilo-admin-field">
        <option value="a" <?php selected($pfad_typ,'a'); ?>>Pfad A — Betroffene</option>
        <option value="b" <?php selected($pfad_typ,'b'); ?>>Pfad B — Begleitende</option>
      </select>
    </p>
    <p>
      <label><strong>Focus Keyword</strong></label><br>
      <input type="text" name="focus_keyword" value="<?php echo esc_attr($focus_kw); ?>" class="widefat thilo-admin-field">
    </p>
    <p>
      <label><strong>Lesezeit (Minuten)</strong></label><br>
      <input type="number" name="lesezeit" value="<?php echo esc_attr($lesezeit); ?>" class="widefat thilo-admin-field" min="1" max="60">
    </p>
    <?php
}

function thilo_buch_meta_box( $post ) {
    wp_nonce_field( 'thilo_buch_meta', 'thilo_buch_nonce' );
    $band      = get_post_meta( $post->ID, '_band_label', true );
    $untertitel = get_post_meta( $post->ID, '_untertitel', true );
    $cover_url = get_post_meta( $post->ID, '_cover_url', true );
    $tag_label = get_post_meta( $post->ID, '_tag_label', true );
    ?>
    <p>
      <label><strong>Band-Label</strong> (z.B. "LifeTime Journey · Band 1")</label><br>
      <input type="text" name="band_label" value="<?php echo esc_attr($band); ?>" class="widefat thilo-admin-field">
    </p>
    <p>
      <label><strong>Untertitel</strong></label><br>
      <input type="text" name="untertitel" value="<?php echo esc_attr($untertitel); ?>" class="widefat thilo-admin-field">
    </p>
    <p>
      <label><strong>Cover-URL</strong></label><br>
      <input type="text" name="cover_url" value="<?php echo esc_attr($cover_url); ?>" class="widefat thilo-admin-field">
    </p>
    <p>
      <label><strong>Tag-Label</strong> (z.B. "Jetzt vorbestellen")</label><br>
      <input type="text" name="tag_label" value="<?php echo esc_attr($tag_label); ?>" class="widefat thilo-admin-field">
    </p>
    <?php
}

// ─── Save Meta Fields ──────────────────────────────────────────────────────────
add_action( 'save_post_leitpfad', function( $post_id ) {
    if ( ! isset( $_POST['thilo_leitpfad_nonce'] ) ) return;
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['thilo_leitpfad_nonce'] ) ), 'thilo_leitpfad_meta' ) ) return;
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $pfad_typ = isset( $_POST['pfad_typ'] ) ? sanitize_text_field( wp_unslash( $_POST['pfad_typ'] ) ) : '';

    update_post_meta( $post_id, '_pfad_typ',       $pfad_typ );
    update_post_meta( $post_id, '_focus_keyword',  isset( $_POST['focus_keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['focus_keyword'] ) ) : '' );
    update_post_meta( $post_id, '_lesezeit',       isset( $_POST['lesezeit'] ) ? absint( wp_unslash( $_POST['lesezeit'] ) ) : 0 );

    $pfad_term = thilo_get_pfad_term_by_type( $pfad_typ );
    if ( $pfad_term ) {
        wp_set_object_terms( $post_id, [ (int) $pfad_term->term_id ], 'pfad', false );
    }
});

add_action( 'save_post_buch', function( $post_id ) {
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    // Buch-Details (Meta Box: buch_meta)
    if ( isset( $_POST['thilo_buch_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['thilo_buch_nonce'] ) ), 'thilo_buch_meta' ) ) {
        update_post_meta( $post_id, '_band_label',  isset( $_POST['band_label'] ) ? sanitize_text_field( wp_unslash( $_POST['band_label'] ) ) : '' );
        update_post_meta( $post_id, '_untertitel',  isset( $_POST['untertitel'] ) ? sanitize_text_field( wp_unslash( $_POST['untertitel'] ) ) : '' );
        update_post_meta( $post_id, '_cover_url',   isset( $_POST['cover_url'] ) ? esc_url_raw( wp_unslash( $_POST['cover_url'] ) ) : '' );
        update_post_meta( $post_id, '_tag_label',   isset( $_POST['tag_label'] ) ? sanitize_text_field( wp_unslash( $_POST['tag_label'] ) ) : '' );
    }

    // Kauf-URL (Meta Box: buch_kauf_url)
    if ( isset( $_POST['thilo_kauf_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['thilo_kauf_nonce'] ) ), 'thilo_kauf_url' ) ) {
        update_post_meta( $post_id, '_kauf_url', isset( $_POST['kauf_url'] ) ? esc_url_raw( wp_unslash( $_POST['kauf_url'] ) ) : '' );
    }
});
