<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Admin Health Checks
 *
 * Zeigt Warnungen im WP-Backend wenn Konfigurationen
 * das Theme im Frontend beeinflussen könnten.
 */
add_action( 'admin_notices', function() {

    // WP_DEBUG_DISPLAY: PHP-Fehler wären im Frontend sichtbar
    // Nur warnen wenn WP_DEBUG ebenfalls aktiv ist — sonst gibt es
    // keine Fehler die angezeigt werden könnten (false positive vermeiden).
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
        echo '<div class="notice notice-warning is-dismissible"><p><strong>Theme Health:</strong> <code>WP_DEBUG_DISPLAY</code> ist aktiv — PHP-Fehler können im öffentlichen Frontend sichtbar sein. In <code>wp-config.php</code> auf <code>false</code> setzen vor dem Go-Live.</p></div>';
    }

    // ACF fehlt: thilo_get_field_safe() greift ins Leere
    if ( ! function_exists( 'get_field' ) ) {
        echo '<div class="notice notice-error"><p><strong>Theme Health:</strong> Advanced Custom Fields (ACF) ist nicht aktiv. Startseiten-Inhalte (Hero, Über mich, Leitpfade-Sektion) werden nicht korrekt geladen.</p></div>';
    }

} );
