<?php
/**
 * Frontend filters and hero pattern rendering.
 */


// ─── Mobile Menü Links mit nav-mobile-link Klasse ─────────────────────────────
add_filter( 'nav_menu_link_attributes', function( $atts, $item, $args ) {
    if ( isset($args->menu_class) && $args->menu_class === 'nav-mobile-list' ) {
        $existing_class = isset( $atts['class'] ) ? trim( (string) $atts['class'] ) : '';
        $atts['class']  = trim( $existing_class . ' nav-mobile-link' );
    }
    return $atts;
}, 10, 3 );

// ─── Beitragsbild nicht automatisch im Content anzeigen ───────────────────────
add_filter( 'the_content', function( $content ) {
    if ( is_single() && has_post_thumbnail() ) {
        $thumb_id  = get_post_thumbnail_id();
        $thumb_url = wp_get_attachment_image_src( $thumb_id, 'full' );
        if ( $thumb_url ) {
            $content = preg_replace( '/<img[^>]+' . preg_quote($thumb_url[0], '/') . '[^>]*>/i', '', $content );
        }
    }
    return $content;
});


// ─── Hero-Muster ──────────────────────────────────────────────────────────────
function thilo_hero_pattern() {
    $out = '<div class="site-hero-pattern" aria-hidden="true">';
    for ( $r = 0; $r < 150; $r++ ) {
        $out .= '<div class="site-hero-row' . ( $r % 2 ? ' offset' : '' ) . '">';
        for ( $c = 0; $c < 120; $c++ ) {
            $out .= '<span class="site-hero-th">TH</span><span class="site-hero-diamond"></span>';
        }
        $out .= '</div>';
    }
    $out .= '</div>';
    return $out;

}
