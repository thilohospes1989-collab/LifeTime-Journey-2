<?php
/**
 * Breadcrumb rendering helpers.
 */

// ─── Breadcrumbs ───────────────────────────────────────────────────────────────
function thilo_breadcrumbs() {
    if ( is_front_page() ) {
        return;
    }

    $sep = '<span class="breadcrumbs-sep" aria-hidden="true">›</span>';

    if ( is_single() && get_post_type() === 'post' ) {
        $trail_items = [
            '<a href="' . esc_url( home_url( '/' ) ) . '">Start</a>',
            '<a href="' . esc_url( thilo_get_themenbereiche_page_url() ) . '">Themenbereiche</a>',
        ];

        $categories          = get_the_category();
        $default_category_id = thilo_get_default_category_id();
        $primary_category    = null;

        if ( $categories && ! is_wp_error( $categories ) ) {
            foreach ( $categories as $category ) {
                if ( (int) $category->term_id !== $default_category_id ) {
                    $primary_category = $category;
                    break;
                }
            }

            if ( ! $primary_category ) {
                $primary_category = $categories[0];
            }
        }

        if ( $primary_category instanceof WP_Term ) {
            $trail_items[] = '<a href="' . esc_url( get_category_link( $primary_category->term_id ) ) . '">' . esc_html( $primary_category->name ) . '</a>';
        }

        echo '<nav class="breadcrumbs breadcrumbs--stacked" aria-label="Breadcrumb">';
        echo '<div class="breadcrumbs-trail">' . implode( $sep, $trail_items ) . '</div>';
        echo '<div class="breadcrumbs-current-row"><span class="breadcrumbs-current">' . esc_html( get_the_title() ) . '</span></div>';
        echo '</nav>';
        return;
    }

    if ( is_single() && get_post_type() === 'leitpfad' ) {
        $trail_items = array(
            '<a href="' . esc_url( home_url( '/' ) ) . '">Start</a>',
            '<a href="' . esc_url( thilo_get_leitpfad_selection_url() ) . '">Leitpfade</a>',
        );

        $terms = get_the_terms( get_the_ID(), 'phase' );
        if ( $terms && ! is_wp_error( $terms ) ) {
            $phase_term = array_shift( $terms );
            $trail_items[] = '<a href="' . esc_url( get_term_link( $phase_term ) ) . '">' . esc_html( $phase_term->name ) . '</a>';
        }

        echo '<nav class="breadcrumbs breadcrumbs--stacked" aria-label="Breadcrumb">';
        echo '<div class="breadcrumbs-trail">' . implode( $sep, $trail_items ) . '</div>';
        echo '<div class="breadcrumbs-current-row"><span class="breadcrumbs-current">' . esc_html( get_the_title() ) . '</span></div>';
        echo '</nav>';
        return;
    }

    echo '<nav class="breadcrumbs" aria-label="Breadcrumb">';
    echo '<a href="' . esc_url( home_url( '/' ) ) . '">Start</a>';

    if ( is_single() ) {
        $post_type = get_post_type();
        if ( $post_type === 'buch' ) {
            echo $sep . '<a href="' . esc_url( thilo_get_books_page_url() ) . '">Bücher</a>';
        }
        echo $sep . '<span class="breadcrumbs-current">' . esc_html( get_the_title() ) . '</span>';

    } elseif ( is_tax( 'phase' ) ) {
        echo $sep . '<a href="' . esc_url( thilo_get_leitpfad_selection_url() ) . '">Leitpfade</a>';
        echo $sep . '<span class="breadcrumbs-current">' . esc_html( single_term_title( '', false ) ) . '</span>';

    } elseif ( is_tax( 'pfad' ) ) {
        echo $sep . '<a href="' . esc_url( thilo_get_leitpfad_selection_url() ) . '">Leitpfade</a>';
        echo $sep . '<span class="breadcrumbs-current">' . esc_html( single_term_title( '', false ) ) . '</span>';

    } elseif ( is_category() ) {
        $themes_page = get_page_by_path( 'themenbereiche' );
        $themes_url  = $themes_page ? get_permalink( $themes_page ) : home_url( '/themenbereiche/' );
        echo $sep . '<a href="' . esc_url( $themes_url ) . '">Themenbereiche</a>';
        echo $sep . '<span class="breadcrumbs-current">' . esc_html( single_cat_title( '', false ) ) . '</span>';

    } elseif ( thilo_is_leitpfad_archive_page() ) {
        echo $sep . '<span class="breadcrumbs-current">Leitpfad-Archiv</span>';

    } elseif ( is_post_type_archive( 'leitpfad' ) ) {
        echo $sep . '<span class="breadcrumbs-current">Leitpfade</span>';

    } elseif ( is_page() ) {
        echo $sep . '<span class="breadcrumbs-current">' . esc_html( get_the_title() ) . '</span>';

    } elseif ( is_search() ) {
        echo $sep . '<span class="breadcrumbs-current">Suche: ' . esc_html( get_search_query() ) . '</span>';
    }

    echo '</nav>';
}
