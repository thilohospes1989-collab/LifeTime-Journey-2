<?php
/**
 * Theme helper functions and excerpt helpers.
 */

// ─── Helper: Phase + Pfad ─────────────────────────────────────────────────────
function thilo_phase_sort_key( $term ) {
    $slug = is_object($term) ? (string) $term->slug : (string) $term;
    $name = is_object($term) ? (string) $term->name : (string) $term;
    $hay  = strtolower( $slug . ' ' . $name );

    if ( str_contains( $hay, 'einfuehrung' ) || str_contains( $hay, 'einführung' ) ) return 0;
    if ( preg_match('/phase[-_ ]?0/', $hay) || str_contains($hay, 'akut') ) return 10;
    if ( preg_match('/phase[-_ ]?1/', $hay) || str_contains($hay, 'orientierung') ) return 20;
    if ( preg_match('/phase[-_ ]?2/', $hay) || str_contains($hay, 'stabil') ) return 30;
    if ( preg_match('/phase[-_ ]?3/', $hay) || str_contains($hay, 'kontakt') ) return 40;
    if ( preg_match('/phase[-_ ]?4/', $hay) || str_contains($hay, 'bindung') || str_contains($hay, 'integration') ) return 50;
    return 999;
}

function thilo_get_ordered_phase_terms( $args = [] ) {
    $terms = get_terms( wp_parse_args( $args, [
        'taxonomy'   => 'phase',
        'hide_empty' => true,
    ] ) );
    if ( empty($terms) || is_wp_error($terms) ) return [];
    usort( $terms, function( $a, $b ) {
        $ka = thilo_phase_sort_key( $a );
        $kb = thilo_phase_sort_key( $b );
        if ( $ka === $kb ) {
            return strnatcasecmp( $a->name, $b->name );
        }
        return $ka <=> $kb;
    } );
    return $terms;
}

function thilo_get_phase_term( $post_id = null ) {
    $terms = get_the_terms( $post_id ?? get_the_ID(), 'phase' );
    if ( $terms && ! is_wp_error($terms) ) {
        $terms = array_values( $terms );
        usort( $terms, function( $a, $b ) { return thilo_phase_sort_key($a) <=> thilo_phase_sort_key($b); } );
        return $terms[0];
    }
    return null;
}

function thilo_get_phase_label( $post_id = null ) {
    $term = thilo_get_phase_term( $post_id );
    return $term ? $term->name : '';
}

function thilo_detect_pfad_type_from_term( $term ) {
    if ( ! $term || is_wp_error( $term ) ) return '';
    $slug = strtolower( trim( $term->slug ?? '' ) );
    $name = strtolower( trim( $term->name ?? '' ) );
    $desc = strtolower( trim( $term->description ?? '' ) );
    $hay  = $slug . ' ' . $name . ' ' . $desc;

    if ( str_contains( $hay, 'pfad-b' ) || str_contains( $hay, 'begleit' ) ) return 'b';
    if ( str_contains( $hay, 'pfad-a' ) || str_contains( $hay, 'sternenkind' ) || str_contains( $hay, 'betroffen' ) ) return 'a';

    // Fallback: slug ends with -b or is exactly "b"
    if ( $slug === 'b' || substr( $slug, -2 ) === '-b' ) return 'b';
    if ( $slug === 'a' || substr( $slug, -2 ) === '-a' ) return 'a';

    return '';
}

function thilo_get_pfad_term( $post_id = null ) {
    $terms = get_the_terms( $post_id ?? get_the_ID(), 'pfad' );
    if ( $terms && ! is_wp_error($terms) ) {
        $terms = array_values( $terms );
        usort( $terms, function( $a, $b ) {
            $wa = thilo_detect_pfad_type_from_term( $a ) === 'a' ? 0 : 1;
            $wb = thilo_detect_pfad_type_from_term( $b ) === 'a' ? 0 : 1;
            return $wa <=> $wb;
        } );
        return $terms[0];
    }
    return null;
}

function thilo_get_pfad_type( $post_id = null ) {
    $post_id = $post_id ?? get_the_ID();
    $term = thilo_get_pfad_term( $post_id );
    $type = $term ? thilo_detect_pfad_type_from_term( $term ) : '';
    if ( $type === 'a' || $type === 'b' ) return $type;

    $meta = get_post_meta( $post_id, '_pfad_typ', true );
    if ( $meta === 'a' || $meta === 'b' ) {
        return $meta;
    }

    $post = get_post( $post_id );
    if ( $post && $post->post_type !== 'leitpfad' ) {
        return '';
    }

    return 'a';
}

function thilo_get_pfad_term_by_type( $type = 'a' ) {
    $type = $type === 'b' ? 'b' : 'a';
    $terms = get_terms([
        'taxonomy'   => 'pfad',
        'hide_empty' => false,
    ]);
    if ( empty( $terms ) || is_wp_error( $terms ) ) return null;

    foreach ( $terms as $term ) {
        if ( thilo_detect_pfad_type_from_term( $term ) === $type ) {
            return $term;
        }
    }

    return null;
}

function thilo_get_pfad_short_label( $post_id = null ) {
    $type = thilo_get_pfad_type( $post_id );
    if ( $type === 'a' ) return 'Pfad A';
    if ( $type === 'b' ) return 'Pfad B';
    return '';
}

function thilo_get_pfad_label( $post_id = null ) {
    $type = thilo_get_pfad_type( $post_id );
    if ( $type === 'a' ) return 'Pfad A · Betroffene';
    if ( $type === 'b' ) return 'Pfad B · Begleitende';
    return '';
}

function thilo_get_pfad_archive_link( $type = 'a' ) {
    $selection_url = thilo_get_leitpfad_selection_url();
    return add_query_arg( 'pfad', $type === 'b' ? 'b' : 'a', $selection_url );
}

function thilo_get_leitpfad_selection_url() {
    return home_url( '/leitpfade/' );
}

function thilo_get_leitpfad_archive_url() {
    return home_url( '/leitpfad-archiv/' );
}

function thilo_is_leitpfad_archive_page() {
    return (bool) get_query_var( 'thilo_leitpfad_archiv' );
}

function thilo_get_page_url_by_candidates( $candidates, $fallback = '' ) {
    foreach ( (array) $candidates as $candidate ) {
        if ( ! $candidate ) {
            continue;
        }

        $page = get_page_by_path( $candidate );
        if ( $page ) {
            return get_permalink( $page );
        }
    }

    return $fallback ?: home_url('/');
}

function thilo_get_about_page_url() {
    return thilo_get_page_url_by_candidates( [ 'ueber-mich', 'uber-mich' ], home_url('/#about-me') );
}

function thilo_get_themenbereiche_page_url() {
    return thilo_get_page_url_by_candidates( [ 'themenbereiche' ], home_url('/themenbereiche/') );
}

function thilo_get_books_page_url() {
    $archive = get_post_type_archive_link( 'buch' );
    if ( $archive ) {
        return $archive;
    }

    return thilo_get_page_url_by_candidates( [ 'buecher', 'bucher', 'books' ], home_url('/') );
}

function thilo_get_posts_page_url() {
    $page_for_posts = (int) get_option( 'page_for_posts' );
    if ( $page_for_posts ) {
        $url = get_permalink( $page_for_posts );
        if ( $url ) {
            return $url;
        }
    }

    return home_url('/#posts');
}

function thilo_get_default_category_id() {
    $default_category = (int) get_option( 'default_category' );
    return $default_category > 0 ? $default_category : 0;
}

function thilo_get_legal_page_url( $slug ) {
    $slug = sanitize_title( (string) $slug );
    return thilo_get_page_url_by_candidates( [ $slug ], home_url('/' . $slug . '/') );
}

function thilo_get_field_safe( $field_name, $default = '', $post_id = false ) {
    if ( function_exists( 'get_field' ) ) {
        $value = get_field( $field_name, $post_id );
        if ( $value !== null && $value !== false && $value !== '' ) {
            return $value;
        }
    }

    return $default;
}

function thilo_get_leitpfad_posts_for_phase( $phase_term, $pfad_filter = '' ) {
    $phase_id = is_object( $phase_term ) ? (int) $phase_term->term_id : (int) $phase_term;
    if ( ! $phase_id ) {
        return [];
    }

    $tax_query = [[
        'taxonomy' => 'phase',
        'field'    => 'term_id',
        'terms'    => $phase_id,
    ]];

    $meta_query = [];

    if ( in_array( $pfad_filter, [ 'a', 'b' ], true ) ) {
        $pfad_term = thilo_get_pfad_term_by_type( $pfad_filter );
        if ( $pfad_term ) {
            $tax_query[] = [
                'taxonomy' => 'pfad',
                'field'    => 'term_id',
                'terms'    => (int) $pfad_term->term_id,
            ];
        } else {
            // Fallback: filter via post meta when no matching pfad taxonomy term exists
            $meta_query[] = [
                'key'     => '_pfad_typ',
                'value'   => $pfad_filter,
                'compare' => '=',
            ];
        }
    }

    $query_args = [
        'post_type'           => 'leitpfad',
        'post_status'         => 'publish',
        'posts_per_page'      => -1,
        'orderby'             => [ 'menu_order' => 'ASC', 'date' => 'ASC', 'title' => 'ASC' ],
        'ignore_sticky_posts' => true,
        'tax_query'           => count( $tax_query ) > 1 ? array_merge( [ 'relation' => 'AND' ], $tax_query ) : $tax_query,
    ];

    if ( ! empty( $meta_query ) ) {
        $query_args['meta_query'] = $meta_query;
    }

    $query = new WP_Query( $query_args );

    if ( ! $query->have_posts() ) {
        return [];
    }

    $posts = $query->posts;
    wp_reset_postdata();

    return $posts;
}

function thilo_get_adjacent_leitpfad_post( $post_id, $direction = 'next', $same_pfad = true ) {
    $phase = thilo_get_phase_term( $post_id );
    if ( ! $phase ) {
        return null;
    }

    $pfad_filter = '';
    if ( $same_pfad ) {
        $pfad_filter = thilo_get_pfad_type( $post_id );
    }

    $posts = thilo_get_leitpfad_posts_for_phase( $phase, $pfad_filter );
    if ( empty( $posts ) ) {
        return null;
    }

    $post_ids = array_map( static function( $post ) {
        return (int) $post->ID;
    }, $posts );

    $current_index = array_search( (int) $post_id, $post_ids, true );
    if ( $current_index === false ) {
        return null;
    }

    if ( $direction === 'prev' ) {
        return $posts[ $current_index - 1 ] ?? null;
    }

    return $posts[ $current_index + 1 ] ?? null;
}

function thilo_get_leitpfad_phase_url( $post_id = null ) {
    $post_id = $post_id ?? get_the_ID();
    $archive_url = thilo_get_leitpfad_selection_url();
    $phase = thilo_get_phase_term( $post_id );

    if ( ! $phase ) {
        return $archive_url;
    }

    $args = [
        'phase' => $phase->slug,
    ];

    $pfad_type = thilo_get_pfad_type( $post_id );
    if ( in_array( $pfad_type, [ 'a', 'b' ], true ) ) {
        $args['pfad'] = $pfad_type;
    }

    return add_query_arg( $args, $archive_url );
}

function thilo_get_leitpfad_sibling_post( $post_id, $target_pfad_type ) {
    $phase = thilo_get_phase_term( $post_id );
    if ( ! $phase || ! in_array( $target_pfad_type, [ 'a', 'b' ], true ) ) {
        return null;
    }

    foreach ( thilo_get_leitpfad_posts_for_phase( $phase, $target_pfad_type ) as $candidate ) {
        if ( (int) $candidate->ID !== (int) $post_id ) {
            return $candidate;
        }
    }

    return null;
}

function thilo_get_pfad_description( $type_or_term = '' ) {
    $type = '';
    if ( is_object($type_or_term) ) {
        $type = thilo_detect_pfad_type_from_term( $type_or_term ) ?: 'a';
        if ( ! empty($type_or_term->description) ) return $type_or_term->description;
    } elseif ( $type_or_term === 'a' || $type_or_term === 'b' ) {
        $type = $type_or_term;
    } else {
        $type = thilo_get_pfad_type();
    }
    return $type === 'b' ? 'Haltung, Sprache und Orientierung für Begleitende.' : 'Orientierung für Sternenkindeltern und direkt Betroffene.';
}

function thilo_get_leitpfad_excerpt( $post_id = null ) {
    $post_id = $post_id ?? get_the_ID();
    $excerpt = get_the_excerpt( $post_id );
    if ( $excerpt ) return $excerpt;
    $post = get_post( $post_id );
    if ( ! $post ) return '';
    return wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 24, ' …' );
}

// ─── Excerpt Length ────────────────────────────────────────────────────────────
add_filter( 'excerpt_length', fn() => 28 );
add_filter( 'excerpt_more', fn() => ' …' );

