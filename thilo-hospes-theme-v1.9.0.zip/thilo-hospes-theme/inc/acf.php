<?php
/**
 * ACF local field groups for the front page.
 */

// ─── ACF Felder für die Startseite ────────────────────────────────────────────
add_action( 'acf/init', function() {

    if ( ! function_exists('acf_add_local_field_group') ) return;

    // ── Hero ──────────────────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_hero',
        'title'    => '🏠 Hero — Startseite',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 0,
        'fields'   => [
            [ 'key' => 'field_hero_eyebrow',   'label' => 'Eyebrow (kleiner Text oben)',  'name' => 'hero_eyebrow',   'type' => 'text',     'default_value' => 'Mein Weg durch Schmerz, Heilung & Wachstum' ],
            [ 'key' => 'field_hero_titel',     'label' => 'Titel Zeile 1',               'name' => 'hero_titel',     'type' => 'text',     'default_value' => 'Schwere Dinge tragen —' ],
            [ 'key' => 'field_hero_titel2',    'label' => 'Titel Zeile 2',               'name' => 'hero_titel2',    'type' => 'text',     'default_value' => 'und trotzdem' ],
            [ 'key' => 'field_hero_titel_gold','label' => 'Titel Zeile 3 (gold/kursiv)', 'name' => 'hero_titel_gold','type' => 'text',     'default_value' => 'wachsen.' ],
            [ 'key' => 'field_hero_text',      'label' => 'Untertitel',                  'name' => 'hero_text',      'type' => 'textarea', 'default_value' => 'Psychologie, Trauer und Traumatherapie — aufgeschrieben von jemandem, der diesen Weg selbst gegangen ist. Kein Lehrbuch, keine Floskeln. Erkenntnisse, Ehrlichkeit, Einblicke für andere Sternenkindeltern.' ],
            [ 'key' => 'field_hero_btn1',      'label' => 'Button 1 Text',               'name' => 'hero_btn1',      'type' => 'text',     'default_value' => 'Zur Fallstudie' ],
            [ 'key' => 'field_hero_btn1_url',  'label' => 'Button 1 URL',                'name' => 'hero_btn1_url',  'type' => 'text',     'default_value' => '#about-me' ],
            [ 'key' => 'field_hero_btn2',      'label' => 'Button 2 Text',               'name' => 'hero_btn2',      'type' => 'text',     'default_value' => 'Mehr erfahren' ],
            [ 'key' => 'field_hero_btn2_url',  'label' => 'Button 2 URL',                'name' => 'hero_btn2_url',  'type' => 'text',     'default_value' => '#themes' ],
                        [ 'key' => 'field_hero_bild', 'label' => 'Hero Hintergrundbild (optional)', 'name' => 'hero_bild', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' ],
        ],
    ]);

    // ── Über mich ─────────────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_about',
        'title'    => '👤 Über mich',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 1,
        'fields'   => [
            [ 'key' => 'field_about_name',  'label' => 'Name',      'name' => 'about_name',  'type' => 'text',     'default_value' => 'Thilo Hospes' ],
            [ 'key' => 'field_about_rolle', 'label' => 'Rolle',     'name' => 'about_rolle', 'type' => 'text',     'default_value' => 'Sternenkindvater & Autor' ],
            [ 'key' => 'field_about_bio',   'label' => 'Biographie','name' => 'about_bio',   'type' => 'textarea', 'default_value' => 'Was mich hierher geführt hat, war kein Plan — es war ein Verlust.' ],
                        [ 'key' => 'field_about_portrait', 'label' => 'Portrait-Foto', 'name' => 'about_portrait', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' ],
        ],
    ]);

    // ── Zitate ────────────────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_zitate',
        'title'    => '💬 Zitate',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 2,
        'fields'   => [
            [ 'key' => 'field_zitat1', 'label' => 'Zitat 1', 'name' => 'zitat1', 'type' => 'textarea', 'default_value' => '„Am Grab dachte ich, mein Leben sei vorbei — dass Trauer und Verbitterung das Einzige wären, was bleibt. Ich habe einen Weg herausgefunden. Nicht weil der Schmerz verschwunden ist, sondern weil ich mich dabei nicht verloren habe."' ],
            [ 'key' => 'field_zitat2', 'label' => 'Zitat 2', 'name' => 'zitat2', 'type' => 'textarea', 'default_value' => '„Ich mache das, weil ich damals selbst jemanden gebraucht hätte, der mich in dieser Zeit unterstützt! Deshalb möchte ich heute dieser jemand für andere sein!"' ],
        ],
    ]);

    // ── Bücher Sektion ────────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_buecher',
        'title'    => '📚 Bücher Sektion',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 3,
        'fields'   => [
            [ 'key' => 'field_buecher_titel', 'label' => 'Titel',        'name' => 'buecher_titel', 'type' => 'text',     'default_value' => 'Drei Bände.<br>Eine Geschichte.' ],
            [ 'key' => 'field_buecher_intro', 'label' => 'Einleitungstext', 'name' => 'buecher_intro', 'type' => 'textarea', 'default_value' => 'Jedes Buch beleuchtet eine andere Schicht des Erlebten — vom persönlichen Schmerz über die neurologische Analyse bis hin zu dem, was das Umfeld mit einem Menschen in der Krise macht.' ],
        ],
    ]);

    // ── Leitpfade Sektion ─────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_leitpfade',
        'title'    => '🧭 Leitpfade',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 4,
        'fields'   => [
            [ 'key' => 'field_pfad_a_titel', 'label' => 'Pfad A — Titel',       'name' => 'pfad_a_titel', 'type' => 'text',     'default_value' => 'Du erkennst dich in diesem Verlauf.' ],
            [ 'key' => 'field_pfad_a_text',  'label' => 'Pfad A — Text',        'name' => 'pfad_a_text',  'type' => 'textarea', 'default_value' => 'Zunächst: Alle Inhalte haben Bestand. Niemand, der hier ist, sollte allein bleiben.' ],
            [ 'key' => 'field_pfad_b_titel', 'label' => 'Pfad B — Titel',       'name' => 'pfad_b_titel', 'type' => 'text',     'default_value' => 'Du begleitest einen trauernden Menschen.' ],
            [ 'key' => 'field_pfad_b_text',  'label' => 'Pfad B — Text',        'name' => 'pfad_b_text',  'type' => 'textarea', 'default_value' => 'Was du brauchst, um da zu sein — was hilft und was nicht.' ],
                        [ 'key' => 'field_workbook_cover', 'label' => 'Workbook Cover', 'name' => 'workbook_cover', 'type' => 'image', 'return_format' => 'url', 'preview_size' => 'medium' ],
        ],
    ]);

    // ── YouTube Playlists ─────────────────────────────────────────────────────
    acf_add_local_field_group([
        'key'      => 'group_youtube',
        'title'    => '▶️ YouTube Playlists',
        'location' => [[[ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ]]],
        'menu_order' => 5,
        'fields'   => [
            [
                'key'   => 'field_playlists',
                'label' => 'Playlists',
                'name'  => 'playlists',
                'type'  => 'repeater',
                'min'   => 0,
                'max'   => 10,
                'button_label' => 'Playlist hinzufügen',
                'sub_fields' => [
                    [ 'key' => 'field_pl_label', 'label' => 'Label',       'name' => 'label', 'type' => 'text' ],
                    [ 'key' => 'field_pl_titel', 'label' => 'Titel',       'name' => 'titel', 'type' => 'text' ],
                    [ 'key' => 'field_pl_count', 'label' => 'Beschreibung','name' => 'count', 'type' => 'text' ],
                    [ 'key' => 'field_pl_url',   'label' => 'YouTube URL', 'name' => 'url',   'type' => 'url'  ],
                ],
            ],
        ],
    ]);

});
