<?php
/**
 * Admin styling, editor enhancements and shortcodes.
 */

// ─── Admin Styles ─────────────────────────────────────────────────────────────
add_action( 'admin_enqueue_scripts', function() {
    $screen = get_current_screen();

    if ( ! $screen || ! in_array( $screen->post_type, [ 'leitpfad', 'post', 'buch' ], true ) ) {
        return;
    }

    wp_enqueue_style(
        'thilo-admin',
        get_template_directory_uri() . '/assets/css/admin.css',
        [],
        wp_get_theme()->get( 'Version' )
    );
} );

// ─── Leitgedanke Shortcode ────────────────────────────────────────────────────
function thilo_render_leitgedanke_shortcode( $atts, $content = null ) {
    if ( null === $content ) {
        return '';
    }

    $atts = shortcode_atts(
        [
            'quelle' => '',
            'cite'   => '',
            'class'  => '',
        ],
        $atts,
        'ltj_leitgedanke'
    );

    $extra_classes = [];

    if ( ! empty( $atts['class'] ) ) {
        $raw_classes = preg_split( '/\s+/', (string) $atts['class'] );

        if ( is_array( $raw_classes ) ) {
            foreach ( $raw_classes as $raw_class ) {
                $sanitized = sanitize_html_class( $raw_class );

                if ( '' !== $sanitized ) {
                    $extra_classes[] = $sanitized;
                }
            }
        }
    }

    $classes = trim( 'ltj-leitgedanke ' . implode( ' ', $extra_classes ) );
    $source  = '';

    if ( ! empty( $atts['quelle'] ) ) {
        $source = $atts['quelle'];
    } elseif ( ! empty( $atts['cite'] ) ) {
        $source = $atts['cite'];
    }

    $content = trim( shortcode_unautop( $content ) );
    $content = do_shortcode( $content );
    $content = wp_kses_post( $content );

    if ( '' === $content ) {
        return '';
    }

    $output  = '<figure class="' . esc_attr( $classes ) . '">';
    $output .= '<div class="ltj-leitgedanke__line" aria-hidden="true"></div>';
    $output .= '<blockquote class="ltj-leitgedanke__text">';
    $output .= wpautop( $content );
    $output .= '</blockquote>';

    if ( '' !== $source ) {
        $output .= '<figcaption class="ltj-leitgedanke__source">' . esc_html( $source ) . '</figcaption>';
    }

    $output .= '</figure>';

    return $output;
}
add_shortcode( 'ltj_leitgedanke', 'thilo_render_leitgedanke_shortcode' );
add_shortcode( 'ltj_pullquote', 'thilo_render_leitgedanke_shortcode' );

// ─── Classic Editor: Leitgedanke Button for Leitpfade ────────────────────────
function thilo_is_leitpfad_editor_screen( $screen = null ) {
    if ( ! $screen ) {
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    }

    return $screen && in_array( $screen->post_type, [ 'leitpfad', 'post' ], true ) && in_array( $screen->base, [ 'post', 'post-new' ], true );
}

function thilo_enqueue_leitgedanke_editor_assets( $hook ) {
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
        return;
    }

    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

    if ( ! thilo_is_leitpfad_editor_screen( $screen ) ) {
        return;
    }

    if ( user_can_richedit() ) {
        add_filter( 'mce_external_plugins', 'thilo_register_leitgedanke_mce_plugin' );
        add_filter( 'mce_buttons', 'thilo_register_leitgedanke_mce_button' );
    }

    add_action( 'admin_print_footer_scripts', 'thilo_print_leitgedanke_quicktag_button', 20 );
}
add_action( 'admin_enqueue_scripts', 'thilo_enqueue_leitgedanke_editor_assets' );

function thilo_register_leitgedanke_mce_plugin( $plugins ) {
    $plugins['thilo_leitgedanke'] = get_template_directory_uri() . '/assets/js/editor-leitgedanke.js';

    return $plugins;
}

function thilo_register_leitgedanke_mce_button( $buttons ) {
    $buttons[] = 'thilo_leitgedanke';

    return $buttons;
}

function thilo_print_leitgedanke_quicktag_button() {
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

    if ( ! thilo_is_leitpfad_editor_screen( $screen ) ) {
        return;
    }
    ?>
    <script>
    (function() {
        if (typeof QTags === 'undefined') {
            return;
        }

        if (document.getElementById('qt_content_thilo_leitgedanke')) {
            return;
        }

        QTags.addButton(
            'thilo_leitgedanke',
            'Leitgedanke',
            '[ltj_leitgedanke]\n',
            '\n[/ltj_leitgedanke]',
            '',
            'Leitgedanke einfügen',
            201
        );
    })();
    </script>
    <?php
}

