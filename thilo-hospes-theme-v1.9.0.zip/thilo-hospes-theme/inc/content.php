<?php
/**
 * Leitpfad content panel rendering.
 */

/**
 * Wrap Leitpfad content sections from each H2 to the next H2 in calm panels.
 */
function thilo_render_leitpfad_section_panels( $content ) {
    if ( is_admin() || ! is_singular( 'leitpfad' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    if ( '' === trim( $content ) || false !== strpos( $content, 'ltj-leitpfad-panel' ) ) {
        return $content;
    }

    if ( ! class_exists( 'DOMDocument' ) ) {
        return $content;
    }

    static $is_processing = false;

    if ( $is_processing ) {
        return $content;
    }

    $is_processing = true;

    $previous_state = libxml_use_internal_errors( true );

    $dom = new DOMDocument( '1.0', 'UTF-8' );
    $html = '<?xml encoding="utf-8" ?><div id="ltj-root">' . $content . '</div>';
    $loaded = $dom->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

    if ( ! $loaded ) {
        libxml_clear_errors();
        libxml_use_internal_errors( $previous_state );
        $is_processing = false;
        return $content;
    }

    $root = $dom->getElementById( 'ltj-root' );

    if ( ! $root ) {
        libxml_clear_errors();
        libxml_use_internal_errors( $previous_state );
        $is_processing = false;
        return $content;
    }

    $intro_nodes = array();
    $sections    = array();
    $current     = null;

    foreach ( iterator_to_array( $root->childNodes ) as $node ) {
        $node_html = $dom->saveHTML( $node );

        if ( false === $node_html ) {
            continue;
        }

        $is_heading = XML_ELEMENT_NODE === $node->nodeType && 'h2' === strtolower( $node->nodeName );

        if ( $is_heading ) {
            if ( null !== $current ) {
                $sections[] = $current;
            }

            $current = array(
                'heading' => $node_html,
                'content' => array(),
            );

            continue;
        }

        if ( null === $current ) {
            $intro_nodes[] = $node_html;
        } else {
            $current['content'][] = $node_html;
        }
    }

    if ( null !== $current ) {
        $sections[] = $current;
    }

    libxml_clear_errors();
    libxml_use_internal_errors( $previous_state );
    $is_processing = false;

    if ( empty( $sections ) ) {
        return $content;
    }

    $output = '';
    $intro  = trim( implode( '', $intro_nodes ) );

    if ( '' !== $intro ) {
        $output .= '<div class="ltj-leitpfad-intro">' . $intro . '</div>';
    }

    $faq_html            = thilo_get_leitpfad_faq_section_html( get_the_ID() );
    $faq_inserted        = false;
    $sources_panel_index = null;

    foreach ( $sections as $index => $section ) {
        if ( null === $sources_panel_index && thilo_is_leitpfad_sources_heading( $section['heading'] ) ) {
            $sources_panel_index = $index;
        }
    }

    foreach ( $sections as $index => $section ) {
        if ( ! $faq_inserted && '' !== $faq_html && null !== $sources_panel_index && $index === $sources_panel_index ) {
            $output .= $faq_html;
            $faq_inserted = true;
        }

        $output .= '<section class="ltj-leitpfad-panel reveal" data-ltj-section="' . esc_attr( (string) ( $index + 1 ) ) . '">';
        $output .= $section['heading'];
        $output .= implode( '', $section['content'] );
        $output .= '</section>';
    }

    if ( ! $faq_inserted && '' !== $faq_html ) {
        $output .= $faq_html;
    }

    return $output;
}
add_filter( 'the_content', 'thilo_render_leitpfad_section_panels', 20 );
