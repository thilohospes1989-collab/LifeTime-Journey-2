<?php
/**
 * Rewrite, archive routing and rewrite flushing.
 */

// ─── Track theme version changes so rewrites refresh after updates ─────────────
add_action( 'admin_init', function() {
    $current_version = THILO_THEME_VERSION;
    $stored_version  = get_option( 'thilo_theme_version', '' );

    if ( $stored_version === $current_version ) {
        return;
    }

    update_option( 'thilo_theme_version', $current_version );
    update_option( 'thilo_flush_rewrite_rules', 1 );
});

// ─── Flush Rewrite Rules after registration on activation ─────────────────────
add_action( 'after_switch_theme', function() {
    update_option( 'thilo_flush_rewrite_rules', 1 );
});

add_action( 'init', function() {
    if ( ! get_option( 'thilo_flush_rewrite_rules' ) ) {
        return;
    }

    flush_rewrite_rules();
    delete_option( 'thilo_flush_rewrite_rules' );
}, 20 );


add_filter( 'query_vars', function( $vars ) {
    $vars[] = 'thilo_leitpfad_archiv';
    return $vars;
} );

add_action( 'init', function() {
    add_rewrite_rule( '^leitpfad-archiv/?$', 'index.php?thilo_leitpfad_archiv=1', 'top' );
    add_rewrite_rule( '^leitpfad-archiv/page/([0-9]{1,})/?$', 'index.php?thilo_leitpfad_archiv=1&paged=$matches[1]', 'top' );
}, 11 );

add_filter( 'template_include', function( $template ) {
    if ( ! thilo_is_leitpfad_archive_page() ) {
        return $template;
    }

    $custom_template = locate_template( 'page-leitpfad-archiv.php' );

    return $custom_template ?: $template;
} );

add_action( 'template_redirect', function() {
    if ( ! thilo_is_leitpfad_archive_page() ) {
        return;
    }

    global $wp_query;

    if ( $wp_query instanceof WP_Query ) {
        $wp_query->is_404 = false;
    }

    status_header( 200 );
} );

add_filter( 'pre_get_document_title', function( $title ) {
    if ( thilo_is_leitpfad_archive_page() ) {
        return 'Leitpfad-Archiv';
    }

    return $title;
} );
