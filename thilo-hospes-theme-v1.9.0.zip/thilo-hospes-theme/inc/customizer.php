<?php
/**
 * Customizer settings and controls.
 */

// ─── Customizer: Portrait + Workbook Cover ─────────────────────────────────────
add_action( 'customize_register', function( $wp_customize ) {

    $wp_customize->add_section( 'thilo_bilder', [
        'title'    => 'Bilder',
        'priority' => 30,
    ]);

    // Portrait
    $wp_customize->add_setting( 'thilo_portrait', [
        'default'           => '',
        'sanitize_callback' => 'absint',
    ]);
    $wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'thilo_portrait', [
        'label'     => 'Portrait (Über mich)',
        'section'   => 'thilo_bilder',
        'mime_type' => 'image',
    ]));

    // Workbook Cover
    $wp_customize->add_setting( 'thilo_workbook_cover', [
        'default'           => '',
        'sanitize_callback' => 'absint',
    ]);
    $wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'thilo_workbook_cover', [
        'label'     => 'Workbook Cover (Leitpfade)',
        'section'   => 'thilo_bilder',
        'mime_type' => 'image',
    ]));

    // ── Social Media & Analytics ──────────────────────────────────────────────
    $wp_customize->add_section( 'thilo_social', [
        'title'    => 'Social Media & Externe Links',
        'priority' => 31,
    ]);

    // YouTube
    $wp_customize->add_setting( 'thilo_youtube_url', [
        'default'           => 'https://youtube.com/@thilohospes',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control( 'thilo_youtube_url', [
        'label'   => 'YouTube-Kanal URL',
        'section' => 'thilo_social',
        'type'    => 'url',
    ]);

    // Google Analytics
    $wp_customize->add_setting( 'thilo_ga_id', [
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control( 'thilo_ga_id', [
        'label'       => 'Google Analytics Measurement ID',
        'description' => 'Format: G-XXXXXXXXXX — nur nach Nutzer-Zustimmung aktiv (DSGVO-konform)',
        'section'     => 'thilo_social',
        'type'        => 'text',
    ]);

});
