<?php
/**
 * Template Name: Orientierungs-Quiz
 */
get_header();
?>

<section class="site-hero site-hero--slim">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">LifeTime Journey</div>
    <h1 class="section-title reveal stagger-1">Wo stehst du<br><em>gerade?</em></h1>
    <p class="archive-desc reveal stagger-2">Drei kurze Fragen — du bekommst sofort die Artikel, die zu deiner Situation passen.</p>
  </div>
</section>

<?php get_template_part( 'section-quiz' ); ?>

<?php get_footer(); ?>
