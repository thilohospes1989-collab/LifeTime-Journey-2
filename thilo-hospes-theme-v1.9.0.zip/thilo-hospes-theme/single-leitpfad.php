<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<?php
$post_id      = get_the_ID();
$phase_label  = thilo_get_phase_label( $post_id );
$pfad_typ     = thilo_get_pfad_type( $post_id );
$pfad_label   = thilo_get_pfad_label( $post_id );
$pfad_class   = $pfad_typ === 'b' ? 'pfad-b' : 'pfad-a';
$lesezeit     = get_post_meta( $post_id, '_lesezeit', true );
$sibling_pfad = $pfad_typ === 'b' ? 'a' : 'b';
$sibling      = thilo_get_leitpfad_sibling_post( $post_id, $sibling_pfad );
$prev         = thilo_get_adjacent_leitpfad_post( $post_id, 'prev', true );
$next         = thilo_get_adjacent_leitpfad_post( $post_id, 'next', true );
$phase_term    = thilo_get_phase_term( $post_id );
$phase_url     = thilo_get_leitpfad_phase_url( $post_id );
$nav_count     = 0;

if ( $prev ) {
	$nav_count++;
}

if ( $phase_term && $phase_url ) {
	$nav_count++;
}

if ( $next ) {
	$nav_count++;
}

$nav_class = 'is-triple';

if ( 1 === $nav_count ) {
	$nav_class = 'is-single';
} elseif ( 2 === $nav_count ) {
	$nav_class = 'is-double';
}
?>

<section class="post-hero post-hero--leitpfad">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="post-hero-inner post-hero-inner--leitpfad">
    <h1 class="post-hero-title reveal stagger-1"><?php echo esc_html( get_the_title() ); ?></h1>
    <?php thilo_breadcrumbs(); ?>
    <div class="post-hero-eyebrow reveal">
      <?php if ( $phase_label ) : ?>
        <?php echo esc_html( $phase_label ); ?>
      <?php endif; ?>
      <?php if ( $pfad_label ) : ?>
        <span class="post-path-badge <?php echo esc_attr( $pfad_class ); ?>">
          <?php echo esc_html( $pfad_label ); ?>
        </span>
      <?php endif; ?>
    </div>
    <div class="post-hero-meta reveal stagger-2">
      <span><?php echo esc_html( get_the_date( 'd. F Y' ) ); ?></span>
      <?php if ( $lesezeit ) : ?>
        <span class="post-meta-sep"></span>
        <span><?php echo absint( $lesezeit ); ?> Min. Lesezeit</span>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php if ( has_post_thumbnail() ) : ?>
  <div class="leitpfad-featured-media">
    <figure class="leitpfad-featured-media__inner">
      <?php the_post_thumbnail( 'large', [ 'class' => 'leitpfad-featured-media__image', 'loading' => 'eager' ] ); ?>
    </figure>
  </div>
<?php endif; ?>

<article class="post-body" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <?php the_content(); ?>
</article>


<section class="leitpfad-end-nav-wrap" aria-label="Leitpfad Navigation">
  <nav class="leitpfad-end-nav <?php echo esc_attr( $nav_class ); ?>" aria-label="Leitpfad Schritte">
    <?php if ( $prev ) : ?>
      <a class="leitpfad-end-nav-item leitpfad-end-nav-item--prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
        <div class="leitpfad-end-nav-label">Vorheriger Schritt</div>
        <div class="leitpfad-end-nav-title"><?php echo esc_html( get_the_title( $prev ) ); ?></div>
      </a>
    <?php endif; ?>

    <?php if ( $phase_term && $phase_url ) : ?>
      <a class="leitpfad-end-nav-item leitpfad-end-nav-item--phase leitpfad-end-nav-item--simple" href="<?php echo esc_url( $phase_url ); ?>">
        <div class="leitpfad-end-nav-label">Zurück zur Leitpfad-Auswahl</div>
      </a>
    <?php endif; ?>

    <?php if ( $next ) : ?>
      <a class="leitpfad-end-nav-item leitpfad-end-nav-item--next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
        <div class="leitpfad-end-nav-label">Nächster Schritt</div>
        <div class="leitpfad-end-nav-title"><?php echo esc_html( get_the_title( $next ) ); ?></div>
      </a>
    <?php endif; ?>
  </nav>
</section>

<?php endwhile; ?>

<?php get_footer(); ?>
