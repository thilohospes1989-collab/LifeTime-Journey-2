<?php
get_header();

$paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );

$leitpfad_query = new WP_Query(
    array(
        'post_type'           => 'leitpfad',
        'post_status'         => 'publish',
        'posts_per_page'      => 12,
        'paged'               => $paged,
        'orderby'             => array(
            'menu_order' => 'ASC',
            'date'       => 'DESC',
            'title'      => 'ASC',
        ),
        'ignore_sticky_posts' => true,
        'no_found_rows'       => false,
    )
);
?>


<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Archiv</div>
    <h1 class="section-title reveal stagger-1">Leitpfad-Archiv</h1>
    <p class="archive-desc archive-desc--narrow reveal stagger-2">Eine ruhige Übersicht aller veröffentlichten Leitpfad-Artikel. Hier findest du jeden Text direkt verlinkt — unabhängig von Pfad, Phase oder Quiz.</p>
  </div>
</section>

<section class="leitpfad-archive-page">
  <div class="leitpfad-archive-page__inner">
    <?php if ( $leitpfad_query->have_posts() ) : ?>
      <div class="leitpfad-archive-page__meta reveal">Aktuell verfügbar: <?php echo esc_html( (string) (int) $leitpfad_query->found_posts ); ?> Leitpfad-Artikel</div>
      <div class="archive-grid leitpfad-archive-grid">
        <?php while ( $leitpfad_query->have_posts() ) : $leitpfad_query->the_post(); ?>
          <?php
          $post_id     = get_the_ID();
          $phase_label = thilo_get_phase_label( $post_id );
          $pfad_label  = thilo_get_pfad_label( $post_id );
          $lesezeit    = (int) get_post_meta( $post_id, '_lesezeit', true );
          $meta_parts  = array_filter(
              array(
                  $pfad_label,
                  $phase_label,
                  $lesezeit ? $lesezeit . ' Min. Lesezeit' : '',
              )
          );
          ?>
          <a class="archive-card leitpfad-archive-card reveal" href="<?php the_permalink(); ?>">
            <div class="archive-card-content">
              <?php if ( ! empty( $meta_parts ) ) : ?>
                <div class="archive-card-phase"><?php echo esc_html( implode( ' · ', $meta_parts ) ); ?></div>
              <?php endif; ?>
              <h2 class="archive-card-title"><?php the_title(); ?></h2>
              <p class="archive-card-excerpt"><?php echo esc_html( thilo_get_leitpfad_excerpt( $post_id ) ); ?></p>
              <div class="archive-card-meta">Artikel öffnen →</div>
            </div>
          </a>
        <?php endwhile; ?>
      </div>

      <?php
      $pagination = paginate_links(
          array(
              'base'      => trailingslashit( thilo_get_leitpfad_archive_url() ) . 'page/%#%/',
              'format'    => '',
              'current'   => $paged,
              'total'     => max( 1, (int) $leitpfad_query->max_num_pages ),
              'mid_size'  => 1,
              'prev_text' => '←',
              'next_text' => '→',
              'type'      => 'list',
          )
      );
      ?>

      <?php if ( $pagination ) : ?>
        <nav class="pagination-wrap reveal" aria-label="Archiv Navigation">
          <?php echo wp_kses_post( $pagination ); ?>
        </nav>
      <?php endif; ?>
    <?php else : ?>
      <div class="leitpfad-archive-page__empty reveal">
        <h2>Noch keine Leitpfad-Artikel veröffentlicht</h2>
        <p>Sobald die ersten Leitpfad-Artikel veröffentlicht sind, erscheinen sie hier automatisch.</p>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php wp_reset_postdata(); ?>
<?php get_footer(); ?>
