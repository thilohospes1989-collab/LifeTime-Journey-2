<?php get_header(); ?>


<section class="archive-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="archive-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Archiv</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html( get_the_archive_title() ); ?></h1>
    <?php if ( get_the_archive_description() ) : ?>
      <div class="archive-desc reveal stagger-2"><?php echo wp_kses_post( wpautop( get_the_archive_description() ) ); ?></div>
    <?php endif; ?>
  </div>
</section>

<div class="archive-grid">
  <?php if ( have_posts() ) : $i = 0; ?>
    <?php while ( have_posts() ) : the_post(); $i++; ?>
      <?php
      $post_type  = get_post_type();
      $lesezeit   = get_post_meta( get_the_ID(), '_lesezeit', true );
      $phase      = $post_type === 'leitpfad' ? thilo_get_phase_label( get_the_ID() ) : '';
      $pfad       = $post_type === 'leitpfad' ? thilo_get_pfad_label( get_the_ID() ) : '';
      $meta_label = $phase && $pfad ? $phase . ' · ' . $pfad : ( $phase ?: ( $pfad ?: ucfirst( $post_type ) ) );
      ?>
      <a class="archive-card reveal stagger-<?php echo ( $i % 4 ) + 1; ?>" href="<?php echo esc_url( get_permalink() ); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
          <div class="archive-card-thumb"><?php the_post_thumbnail( 'medium', [ 'loading' => 'lazy' ] ); ?></div>
        <?php endif; ?>
        <div class="archive-card-content">
          <?php if ( $meta_label ) : ?><div class="archive-card-phase"><?php echo esc_html( $meta_label ); ?></div><?php endif; ?>
          <h2 class="archive-card-title"><?php echo esc_html( get_the_title() ); ?></h2>
          <p class="archive-card-excerpt"><?php echo esc_html( has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 28, ' …' ) ); ?></p>
          <div class="archive-card-meta">
            <?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?>
            <?php if ( $lesezeit ) : ?> · <?php echo absint( $lesezeit ); ?> Min.<?php endif; ?>
          </div>
        </div>
      </a>
    <?php endwhile; ?>
  <?php else : ?>
    <div class="archive-empty">
      <p class="archive-empty-text">Noch keine Inhalte in diesem Archiv.</p>
    </div>
  <?php endif; ?>
</div>

<?php if ( $GLOBALS['wp_query']->max_num_pages > 1 ) : ?>
  <div class="pagination-wrap">
    <?php the_posts_pagination([
      'mid_size'           => 2,
      'prev_text'          => '← Zurück',
      'next_text'          => 'Weiter →',
      'screen_reader_text' => ' ',
    ]); ?>
  </div>
<?php endif; ?>

<?php get_footer(); ?>
