<?php get_header(); ?>


<section class="error-page">
  <div class="error-page-inner">
    <div class="error-page-code">404</div>
    <div class="section-eyebrow section-eyebrow--center error-page-eyebrow">Seite nicht gefunden</div>
    <h1 class="error-page-title">
      Diese Seite gibt es nicht.
    </h1>
    <p class="error-page-text">
      Vielleicht wurde sie verschoben oder der Link ist falsch. Zurück zur Startseite — dort findest du alles.
    </p>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn-primary">Zur Startseite</a>
  </div>
</section>

<?php get_footer(); ?>
