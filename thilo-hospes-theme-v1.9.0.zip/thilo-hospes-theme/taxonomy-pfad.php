<?php get_header(); ?>
<?php
$term         = get_queried_object();
$current_type = thilo_detect_pfad_type_from_term( $term ) ?: 'a';
$term_desc    = thilo_get_pfad_description( $term );
$phase_terms  = thilo_get_ordered_phase_terms( [ 'hide_empty' => true ] );
$archive_url  = thilo_get_leitpfad_selection_url();
?>

<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Leitpfade · Pfad</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html( $term->name ); ?></h1>
    <p class="archive-desc reveal stagger-2"><?php echo esc_html( $term_desc ); ?></p>

    <div class="leitpfad-top-switch reveal stagger-3">
      <a href="<?php echo esc_url( $archive_url ); ?>" class="leitpfad-top-pill">
        <span class="leitpfad-top-pill-label">Alle</span>
        <span class="leitpfad-top-pill-sub">alle Leitpfade</span>
      </a>
      <a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'a' ) ); ?>" class="leitpfad-top-pill <?php echo esc_attr( $current_type === 'a' ? 'active' : '' ); ?>">
        <span class="leitpfad-top-pill-label">Pfad A</span>
        <span class="leitpfad-top-pill-sub">Betroffene</span>
      </a>
      <a href="<?php echo esc_url( thilo_get_pfad_archive_link( 'b' ) ); ?>" class="leitpfad-top-pill <?php echo esc_attr( $current_type === 'b' ? 'active' : '' ); ?>">
        <span class="leitpfad-top-pill-label">Pfad B</span>
        <span class="leitpfad-top-pill-sub">Begleitende</span>
      </a>
    </div>

    <?php if ( $phase_terms ) : ?>
      <div class="archive-filters reveal stagger-4">
        <?php foreach ( $phase_terms as $phase ) : ?>
          <a href="#phase-<?php echo esc_attr( $phase->slug ); ?>" class="archive-filter-btn"><?php echo esc_html( $phase->name ); ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<div class="leitpfad-archive-wrap">
  <?php foreach ( $phase_terms as $phase ) : ?>
    <?php $posts = thilo_get_leitpfad_posts_for_phase( $phase, $current_type ); ?>
    <?php if ( $posts ) : ?>
      <section class="leitpfad-phase-block" id="phase-<?php echo esc_attr( $phase->slug ); ?>">
        <div class="leitpfad-phase-head">
          <div>
            <div class="section-eyebrow"><?php echo esc_html( $current_type === 'b' ? 'Pfad B' : 'Pfad A' ); ?></div>
            <h2 class="leitpfad-phase-title"><?php echo esc_html( $phase->name ); ?></h2>
            <?php if ( ! empty( $phase->description ) ) : ?><p class="leitpfad-phase-desc"><?php echo esc_html( $phase->description ); ?></p><?php endif; ?>
          </div>
          <a class="leitpfad-phase-link" href="<?php echo esc_url( get_term_link( $phase ) ); ?>">Phase öffnen</a>
        </div>
        <div class="leitpfad-card-grid">
          <?php foreach ( $posts as $post ) : setup_postdata( $post ); ?>
            <?php $lesezeit = get_post_meta( $post->ID, '_lesezeit', true ); ?>
            <article class="leitpfad-card pfad-<?php echo esc_attr( $current_type ); ?>">
              <a class="leitpfad-card-link" href="<?php echo esc_url( get_permalink( $post ) ); ?>"></a>
              <div class="leitpfad-card-badges">
                <span class="leitpfad-badge pfad"><?php echo esc_html( thilo_get_pfad_short_label( $post->ID ) ); ?></span>
                <span class="leitpfad-badge phase"><?php echo esc_html( $phase->name ); ?></span>
                <?php if ( $lesezeit ) : ?><span class="leitpfad-badge meta"><?php echo absint( $lesezeit ); ?> Min.</span><?php endif; ?>
              </div>
              <h2 class="leitpfad-card-title"><?php echo esc_html( get_the_title( $post ) ); ?></h2>
              <p class="leitpfad-card-excerpt"><?php echo esc_html( thilo_get_leitpfad_excerpt( $post->ID ) ); ?></p>
            </article>
          <?php endforeach; wp_reset_postdata(); ?>
        </div>
      </section>
    <?php endif; ?>
  <?php endforeach; ?>
</div>

<?php get_footer(); ?>
