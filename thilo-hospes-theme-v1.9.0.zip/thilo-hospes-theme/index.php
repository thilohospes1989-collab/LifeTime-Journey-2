<?php get_header(); ?>


<section class="archive-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="archive-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Inhalte</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html( wp_get_document_title() ?: get_bloginfo( 'name' ) ); ?></h1>
  </div>
</section>

<div class="archive-grid">
  <?php if ( have_posts() ) : $i = 0; ?>
    <?php while ( have_posts() ) : the_post(); $i++; ?>
      <?php $post_type_object = get_post_type_object( get_post_type() ); ?>
      <a class="archive-card reveal stagger-<?php echo ( $i % 4 ) + 1; ?>" href="<?php echo esc_url( get_permalink() ); ?>">
        <?php if ( has_post_thumbnail() ) : ?>
          <div class="archive-card-thumb"><?php the_post_thumbnail( 'medium', [ 'loading' => 'lazy' ] ); ?></div>
        <?php endif; ?>
        <div class="archive-card-content">
          <div class="archive-card-phase"><?php echo esc_html( $post_type_object && isset( $post_type_object->labels->singular_name ) ? $post_type_object->labels->singular_name : 'Beitrag' ); ?></div>
          <h2 class="archive-card-title"><?php echo esc_html( get_the_title() ); ?></h2>
          <p class="archive-card-excerpt"><?php echo esc_html( has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 28, ' …' ) ); ?></p>
          <div class="archive-card-meta"><?php echo esc_html( get_the_date( 'd.m.Y' ) ); ?></div>
        </div>
      </a>
    <?php endwhile; ?>
  <?php else : ?>
    <div class="archive-empty">
      <p class="archive-empty-text">Noch keine Inhalte gefunden.</p>
    </div>
  <?php endif; ?>
</div>

<?php if ( $GLOBALS['wp_query']->max_num_pages > 1 ) : ?>
  <div class="pagination-wrap">
    <?php the_posts_pagination([
      'mid_size'           => 2,
      'prev_text'          => '← Zurück',
      'next_text'          => 'Weiter →',
      'screen_reader_text' => ' ',
    ]); ?>
  </div>
<?php endif; ?>

<?php get_footer(); ?>
