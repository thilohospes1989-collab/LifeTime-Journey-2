# Changelog

## 1.8.6 — 2026-03-28
- `filemtime()`-basierte Asset-Versionierung in `inc/setup.php`: Browser-Cache bricht jetzt automatisch bei jeder Dateiänderung, ohne manuellen Versions-Bump. Fallback auf `THILO_THEME_VERSION` wenn Datei nicht gefunden.
- `inc/health.php` neu: Admin-Warnungen wenn `WP_DEBUG_DISPLAY` aktiv ist oder ACF fehlt.
- `header.php`: Preconnect-Hints für `fonts.googleapis.com` und `fonts.gstatic.com` ergänzt — schnelleres Laden der Google Fonts.

## 1.8.5 — 2026-03-27
- Bereinigt: 50 doppelte CSS-Selektoren auf Root-Ebene zusammengeführt (2702 → 2410 Zeilen). `::before`/`::after`-Kreuz-Pattern korrekt ausgelassen.
- Verschoben: Kauf-URL Meta-Box aus `inc/acf.php` → `inc/meta-boxes.php` (Regression aus v1.8.x behoben).
- Zusammengeführt: 2 `add_meta_boxes`-Hooks → 1 in `inc/meta-boxes.php`.
- Synchronisiert: `THILO_THEME_RELEASE_DATE`, `THILO_THEME_BUILD_ID`, `COPYRIGHT.txt` und `CHANGELOG.md` auf 1.8.5 / 2026-03-27.

## 1.7.7 — 2026-03-25
- Synced package metadata to the current release version in `style.css`, `functions.php`, `README.txt` and `COPYRIGHT.txt`.
- Removed the unused `.nav-spacer` CSS leftover after the hero template cleanup.
- Normalized changelog continuity so recent releases are documented in order.

## 1.7.6 — 2026-03-25
- Removed the extra top offset on hero-based templates by dropping the redundant `nav-spacer` wrapper before hero sections.
- Kept the hero fix at template level without using `!important` or forcing layout overrides in CSS.

## 1.7.5 — 2026-03-25
- Aligned `site-hero` pages visually with the tighter Leitpfad single-hero spacing.
- Removed the automatic bottom push from `.site-hero-inner` so hero content starts naturally from the top.
- Reduced `site-hero` top and bottom spacing on desktop and mobile without using `!important`.

## 1.7.4 — 2026-03-25
- Reworked theme package metadata into a cleaner legal and technical form.
- Reduced the `style.css` header to WordPress-standard theme fields and moved attribution into a separate package notice.
- Replaced informal ownership markers in `functions.php` with release-oriented internal package constants.
- Rewrote `README.txt` and `COPYRIGHT.txt` with cleaner package, authorship and licensing language.
- Expanded `LICENSE.txt` to include the GNU GPL v2 license text plus a package distribution note.

## 1.7.2 — 2026-03-25
- Added expanded theme ownership metadata to `style.css`.
- Centralized internal owner, slug, version and release constants in `functions.php`.
- Added `README.txt`, `COPYRIGHT.txt` and `LICENSE.txt` for package attribution.
- Kept all changes frontend-neutral; no public output was added.
