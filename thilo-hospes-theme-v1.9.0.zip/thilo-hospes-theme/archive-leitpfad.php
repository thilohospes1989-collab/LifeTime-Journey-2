<?php get_header(); ?>
<?php
// ── URL-State ────────────────────────────────────────────────────────────────
$pfad_filter  = isset( $_GET['pfad'] ) ? sanitize_text_field( wp_unslash( $_GET['pfad'] ) ) : '';
$pfad_filter  = in_array( $pfad_filter, [ 'a', 'b' ], true ) ? $pfad_filter : '';

$phase_filter = isset( $_GET['phase'] ) ? sanitize_text_field( wp_unslash( $_GET['phase'] ) ) : '';
$archive_url  = thilo_get_leitpfad_selection_url();

// ── Phasen ermitteln (nur wenn Pfad gewählt) ─────────────────────────────────
$phases_with_posts = [];
if ( $pfad_filter ) {
	$all_phases = thilo_get_ordered_phase_terms( [ 'hide_empty' => true ] );
	if ( $all_phases ) {
		foreach ( $all_phases as $phase ) {
			if ( thilo_get_leitpfad_posts_for_phase( $phase, $pfad_filter ) ) {
				$phases_with_posts[] = $phase;
			}
		}
	}
}

// ── Aktive Phase und Artikel ──────────────────────────────────────────────────
$active_phase = null;
$phase_posts  = [];
if ( $phase_filter && $phases_with_posts ) {
	foreach ( $phases_with_posts as $phase ) {
		if ( $phase->slug === $phase_filter ) {
			$active_phase = $phase;
			break;
		}
	}
}
if ( $active_phase ) {
	$phase_posts = thilo_get_leitpfad_posts_for_phase( $active_phase, $pfad_filter );
}
?>


<section class="site-hero">
  <?php echo thilo_hero_pattern(); ?>
  <div class="site-hero-grad"></div>
  <div class="site-hero-inner">
    <?php thilo_breadcrumbs(); ?>
    <div class="section-eyebrow reveal">Übersicht</div>
    <h1 class="section-title reveal stagger-1"><?php echo esc_html( post_type_archive_title( '', false ) ); ?></h1>
    <p class="archive-desc reveal stagger-2">Texte für Betroffene und Begleitende — wähle deinen Pfad, dann eine Phase, und finde den Artikel, der genau zu deiner Situation passt.</p>
  </div>
</section>

<?php get_template_part( 'section-quiz' ); ?>

<?php // ── Schritt 1: Pfad-Auswahl ──────────────────────────────────────────── ?>
<section class="leitpfad-archive-intro">
  <div class="leitpfad-archive-intro-inner">

    <div class="section-eyebrow reveal stagger-3">Selbstbestimmte Orientierung</div>
    <h2 class="leitpfad-archive-intro-title reveal stagger-4">Wo möchtest du ansetzen?</h2>

    <p class="leitpfad-pfade-intro reveal stagger-5">Wenn du schon eher weißt, wo du stehst, kannst du hier direkt einsteigen. Wähle den Pfad, der eher zu deiner Situation passt, und gehe von dort aus Schritt für Schritt weiter.</p>

    <div class="leitpfad-top-switch leitpfad-top-switch--two reveal stagger-6">
      <a href="<?php echo esc_url( add_query_arg( 'pfad', 'a', $archive_url ) ); ?>"
         class="leitpfad-top-pill<?php echo $pfad_filter === 'a' ? ' active' : ''; ?>">
        <span class="leitpfad-top-pill-label">Pfad A</span>
        <span class="leitpfad-top-pill-sub">Betroffene</span>
      </a>
      <a href="<?php echo esc_url( add_query_arg( 'pfad', 'b', $archive_url ) ); ?>"
         class="leitpfad-top-pill<?php echo $pfad_filter === 'b' ? ' active' : ''; ?>">
        <span class="leitpfad-top-pill-label">Pfad B</span>
        <span class="leitpfad-top-pill-sub">Begleitende</span>
      </a>
    </div>

  </div>
</section>

<?php // ── Schritt 2: Phasen-Auswahl ────────────────────────────────────────── ?>
<?php if ( $pfad_filter && $phases_with_posts ) : ?>
<section class="leitpfad-phase-picker">
  <div class="leitpfad-phase-picker-inner">

    <div class="section-eyebrow reveal">Schritt 2 — Phase</div>
    <p class="leitpfad-pfade-intro reveal">Wähle die Phase, in der du dich gerade befindest — die Texte dort setzen genau dort an, wo du stehst.</p>

    <div class="leitpfad-phase-picker-grid reveal">
      <?php foreach ( $phases_with_posts as $phase ) :
        $phase_url = add_query_arg( [ 'pfad' => $pfad_filter, 'phase' => $phase->slug ], $archive_url );
        $is_active = $active_phase && $active_phase->term_id === $phase->term_id;
        $count     = count( thilo_get_leitpfad_posts_for_phase( $phase, $pfad_filter ) );
      ?>
        <a href="<?php echo esc_url( $phase_url ); ?>"
           class="leitpfad-phase-pill<?php echo $is_active ? ' active' : ''; ?>">
          <span class="leitpfad-phase-pill-name"><?php echo esc_html( $phase->name ); ?></span>
          <?php if ( ! empty( $phase->description ) ) : ?>
            <span class="leitpfad-phase-pill-desc"><?php echo esc_html( $phase->description ); ?></span>
          <?php endif; ?>
          <span class="leitpfad-phase-pill-count"><?php echo absint( $count ); ?> Artikel</span>
        </a>
      <?php endforeach; ?>
    </div>

  </div>
</section>
<?php endif; ?>

<?php // ── Schritt 3: Artikel ───────────────────────────────────────────────── ?>
<?php if ( $active_phase && $phase_posts ) : ?>
<div class="leitpfad-archive-wrap">
  <section class="leitpfad-phase-block" id="phase-<?php echo esc_attr( $active_phase->slug ); ?>">
    <div class="leitpfad-phase-head">
      <div>
        <div class="section-eyebrow">
          Schritt 3 — Leitpfad · Artikel
        </div>
        <?php if ( ! empty( $active_phase->description ) ) : ?>
          <p class="leitpfad-phase-desc"><?php echo esc_html( $active_phase->description ); ?></p>
        <?php endif; ?>
      </div>

    </div>

    <div class="leitpfad-card-grid">
      <?php foreach ( $phase_posts as $post ) : setup_postdata( $post ); ?>
        <?php
        $pfad_type  = thilo_get_pfad_type( $post->ID );
        $pfad_label = thilo_get_pfad_short_label( $post->ID );
        $lesezeit   = get_post_meta( $post->ID, '_lesezeit', true );
        ?>
        <article class="leitpfad-card pfad-<?php echo esc_attr( $pfad_type ?: 'a' ); ?>">
          <a class="leitpfad-card-link" href="<?php echo esc_url( get_permalink( $post ) ); ?>"></a>
          <div class="leitpfad-card-badges">
            <?php if ( $pfad_label ) : ?>
              <span class="leitpfad-badge pfad"><?php echo esc_html( $pfad_label ); ?></span>
            <?php endif; ?>
            <span class="leitpfad-badge phase"><?php echo esc_html( $active_phase->name ); ?></span>
            <?php if ( $lesezeit ) : ?>
              <span class="leitpfad-badge meta"><?php echo absint( $lesezeit ); ?> Min.</span>
            <?php endif; ?>
          </div>
          <h3 class="leitpfad-card-title"><?php echo esc_html( get_the_title( $post ) ); ?></h3>
          <p class="leitpfad-card-excerpt"><?php echo esc_html( thilo_get_leitpfad_excerpt( $post->ID ) ); ?></p>
        </article>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </section>
</div>
<?php endif; ?>

<?php get_footer(); ?>
